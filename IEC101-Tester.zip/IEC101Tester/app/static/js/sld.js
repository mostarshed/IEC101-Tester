/* =========================================================================
   SLD Designer — single-line / mimic diagram editor
   SVG canvas with draggable IEC electrical symbols, wiring, and live IOA
   binding so breakers/disconnectors reflect the real-time point database.
   ========================================================================= */
'use strict';

const SLD = (function(){
  const SVGNS='http://www.w3.org/2000/svg';
  let svg, defs, gWires, gNodes, gOverlay, appState;
  let model = {nodes:[], wires:[]};     // nodes:{id,type,x,y,label,ioa,state,rot}
  let selected=null, tool='select', dragging=null, wireFrom=null;
  let pan={x:0,y:0,scale:1}, viewW=1200, viewH=800;
  let idSeq=1;

  /* ---- symbol library -------------------------------------------------- */
  // each returns an SVG group string drawn in a 60x60 local box, origin centre
  const SYMBOLS = {
    busbar:   {name:'Busbar', w:140, h:14, live:false, draw:()=>`
      <rect x="-70" y="-5" width="140" height="10" rx="2" fill="url(#gBus)" stroke="#3a4e60"/>`},
    breaker:  {name:'Circuit Breaker', live:true, draw:(s)=>{
      const on = s===2||s===true||s==='ON'; const col=on?'var(--green)':(s===1||s===false?'var(--red)':'var(--amber)');
      return `<line x1="0" y1="-30" x2="0" y2="-14" stroke="#5d7183" stroke-width="2"/>
        <line x1="0" y1="14" x2="0" y2="30" stroke="#5d7183" stroke-width="2"/>
        <rect x="-12" y="-14" width="24" height="28" rx="3" fill="url(#gCard)" stroke="${col}" stroke-width="2"/>
        <rect x="-5" y="-7" width="10" height="14" rx="2" fill="${col}" opacity="${on?1:.35}"/>`; }},
    disconnector:{name:'Disconnector', live:true, draw:(s)=>{
      const on = s===2||s===true||s==='ON'; const col=on?'var(--green)':'var(--red)';
      return `<line x1="0" y1="-30" x2="0" y2="-14" stroke="#5d7183" stroke-width="2"/>
        <circle cx="0" cy="-14" r="3" fill="#8aa2b5"/>
        <line x1="0" y1="-14" x2="${on?0:12}" y2="14" stroke="${col}" stroke-width="2.4"/>
        <circle cx="0" cy="14" r="3" fill="#8aa2b5"/>
        <line x1="0" y1="14" x2="0" y2="30" stroke="#5d7183" stroke-width="2"/>`; }},
    earth:    {name:'Earth Switch', live:true, draw:(s)=>{
      const on=s===2||s===true; const col=on?'var(--green)':'#5d7183';
      return `<line x1="0" y1="-30" x2="0" y2="0" stroke="${col}" stroke-width="2"/>
        <line x1="-10" y1="4" x2="10" y2="4" stroke="#8aa2b5" stroke-width="2"/>
        <line x1="-6" y1="10" x2="6" y2="10" stroke="#8aa2b5" stroke-width="2"/>
        <line x1="-3" y1="16" x2="3" y2="16" stroke="#8aa2b5" stroke-width="2"/>`; }},
    transformer:{name:'2-Winding Transformer', live:false, draw:()=>`
      <circle cx="0" cy="-10" r="16" fill="none" stroke="url(#gTx)" stroke-width="2.2"/>
      <circle cx="0" cy="10" r="16" fill="none" stroke="url(#gTx)" stroke-width="2.2"/>
      <line x1="0" y1="-34" x2="0" y2="-26" stroke="#5d7183" stroke-width="2"/>
      <line x1="0" y1="26" x2="0" y2="34" stroke="#5d7183" stroke-width="2"/>`},
    transformer3:{name:'3-Winding Transformer', live:false, draw:()=>`
      <circle cx="0" cy="-12" r="14" fill="none" stroke="url(#gTx)" stroke-width="2"/>
      <circle cx="-11" cy="10" r="14" fill="none" stroke="url(#gTx)" stroke-width="2"/>
      <circle cx="11" cy="10" r="14" fill="none" stroke="url(#gTx)" stroke-width="2"/>`},
    ct:       {name:'Current Transformer', live:false, draw:()=>`
      <line x1="0" y1="-30" x2="0" y2="30" stroke="#5d7183" stroke-width="2"/>
      <circle cx="10" cy="0" r="10" fill="none" stroke="#56a7ff" stroke-width="2"/>`},
    vt:       {name:'Voltage Transformer', live:false, draw:()=>`
      <line x1="0" y1="-30" x2="0" y2="0" stroke="#5d7183" stroke-width="2"/>
      <circle cx="0" cy="8" r="11" fill="none" stroke="#56a7ff" stroke-width="2"/>
      <path d="M-4 20 L0 30 L4 20Z" fill="#5d7183"/>`},
    generator:{name:'Generator', live:false, draw:()=>`
      <circle cx="0" cy="0" r="20" fill="url(#gCard)" stroke="#3ddc84" stroke-width="2"/>
      <text x="0" y="6" text-anchor="middle" fill="#3ddc84" font-size="18" font-family="IBM Plex Mono">G</text>`},
    load:     {name:'Load / Feeder', live:false, draw:()=>`
      <line x1="0" y1="-30" x2="0" y2="-8" stroke="#5d7183" stroke-width="2"/>
      <path d="M-11 -8 L11 -8 L0 16 Z" fill="url(#gCard)" stroke="#f5b544" stroke-width="2"/>`},
    ground:   {name:'Ground', live:false, draw:()=>`
      <line x1="0" y1="-20" x2="0" y2="0" stroke="#5d7183" stroke-width="2"/>
      <line x1="-14" y1="0" x2="14" y2="0" stroke="#8aa2b5" stroke-width="2"/>
      <line x1="-9" y1="6" x2="9" y2="6" stroke="#8aa2b5" stroke-width="2"/>
      <line x1="-4" y1="12" x2="4" y2="12" stroke="#8aa2b5" stroke-width="2"/>`},
    node:     {name:'Junction', live:false, draw:()=>`<circle cx="0" cy="0" r="4" fill="#8aa2b5"/>`},
    meter:    {name:'Measurement', live:true, meas:true, draw:(s,label)=>`
      <rect x="-30" y="-16" width="60" height="32" rx="5" fill="url(#gCard)" stroke="#35d0e0" stroke-width="1.5"/>
      <text x="0" y="5" text-anchor="middle" fill="#35d0e0" font-size="13" font-family="IBM Plex Mono">${label!=null?label:'---'}</text>`},
  };

  const PALETTE_GROUPS = [
    ['Busbars & nodes', ['busbar','node','ground']],
    ['Switchgear', ['breaker','disconnector','earth']],
    ['Transformers', ['transformer','transformer3']],
    ['Instruments', ['ct','vt','meter']],
    ['Sources & loads', ['generator','load']],
  ];

  /* ---- setup ----------------------------------------------------------- */
  function init(state){
    appState=state;
    svg=document.getElementById('sldCanvas');
    buildDefs();
    gWires=mk('g'); gNodes=mk('g'); gOverlay=mk('g');
    svg.append(gWires, gNodes, gOverlay);
    buildPalette();
    bindToolbar();
    bindCanvas();
    resize();
    loadDiagram(true);
    window.addEventListener('resize', resize);
  }

  function mk(tag, attrs){ const e=document.createElementNS(SVGNS,tag);
    if(attrs) for(const k in attrs) e.setAttribute(k,attrs[k]); return e; }

  function buildDefs(){
    defs=mk('defs');
    defs.innerHTML=`
      <linearGradient id="gBus" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#4a5f72"/><stop offset=".5" stop-color="#34475a"/>
        <stop offset="1" stop-color="#1e2d3b"/></linearGradient>
      <linearGradient id="gCard" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#1b2836"/><stop offset="1" stop-color="#0f1823"/></linearGradient>
      <linearGradient id="gTx" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#7cd6e0"/><stop offset="1" stop-color="#2a7580"/></linearGradient>
      <radialGradient id="gGlow"><stop offset="0" stop-color="#35d0e0" stop-opacity=".4"/>
        <stop offset="1" stop-color="#35d0e0" stop-opacity="0"/></radialGradient>
      <pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse">
        <circle cx="1" cy="1" r="1" class="sld-grid-dot"/></pattern>
      <filter id="bevel" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="0" dy="2" stdDeviation="2.5" flood-color="#000" flood-opacity="0.55"/></filter>`;
    svg.appendChild(defs);
    const bg=mk('rect',{x:-2000,y:-2000,width:4000,height:4000,fill:'url(#grid)'});
    svg.appendChild(bg);
  }

  function buildPalette(){
    const host=document.getElementById('sldPalette'); host.innerHTML='';
    for(const [grp,keys] of PALETTE_GROUPS){
      host.appendChild(el('h3',null,grp));
      for(const key of keys){
        const sym=SYMBOLS[key];
        const item=el('div','palette-item');
        item.draggable=true;
        item.innerHTML=`<svg viewBox="-35 -35 70 70">${sym.draw(0,'')}</svg><span>${sym.name}</span>`;
        item.addEventListener('dragstart', ev=>ev.dataTransfer.setData('text/plain', key));
        host.appendChild(item);
      }
    }
  }
  function el(t,c,h){ const e=document.createElement(t); if(c)e.className=c; if(h!=null)e.innerHTML=h; return e; }

  /* ---- toolbar --------------------------------------------------------- */
  function bindToolbar(){
    const setTool=t=>{ tool=t; wireFrom=null;
      document.getElementById('sldHint').textContent =
        t==='wire' ? 'Click a node, then another, to draw a connection' :
        'Drag an element from the palette · click a node to edit it';
      svg.style.cursor = t==='wire'?'crosshair':'default'; };
    document.getElementById('sldSelect').onclick=()=>setTool('select');
    document.getElementById('sldWire').onclick=()=>setTool('wire');
    document.getElementById('sldDelete').onclick=deleteSelected;
    document.getElementById('sldSave').onclick=saveDiagram;
    document.getElementById('sldLoad').onclick=()=>loadDiagram(false);
    document.getElementById('sldClear').onclick=()=>{ if(confirm('Clear the diagram?')){
      model={nodes:[],wires:[]}; selected=null; render(); inspect(); } };
    const zoom=f=>{ pan.scale=Math.max(.3,Math.min(2.5,pan.scale*f)); applyView(); };
    document.getElementById('sldZoomIn').onclick=()=>zoom(1.15);
    document.getElementById('sldZoomOut').onclick=()=>zoom(0.87);
    document.getElementById('sldZoomFit').onclick=()=>{ pan={x:0,y:0,scale:1}; applyView(); };
  }

  /* ---- canvas interaction --------------------------------------------- */
  function bindCanvas(){
    svg.addEventListener('dragover', e=>e.preventDefault());
    svg.addEventListener('drop', e=>{
      e.preventDefault();
      const key=e.dataTransfer.getData('text/plain'); if(!SYMBOLS[key]) return;
      const p=toLocal(e.clientX,e.clientY);
      addNode(key, snap(p.x), snap(p.y));
    });
    svg.addEventListener('mousedown', onDown);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', ()=>{ dragging=null; });
    // wheel zoom
    svg.addEventListener('wheel', e=>{ e.preventDefault();
      const f=e.deltaY<0?1.1:0.9; pan.scale=Math.max(.3,Math.min(2.5,pan.scale*f)); applyView(); },
      {passive:false});
  }
  function onDown(e){
    const g=e.target.closest('[data-node]');
    if(tool==='wire'){
      if(g){ const id=+g.dataset.node;
        if(wireFrom==null){ wireFrom=id; highlight(id,true); }
        else if(wireFrom!==id){ model.wires.push({a:wireFrom,b:id}); highlight(wireFrom,false);
          wireFrom=null; render(); } }
      return;
    }
    if(g){ const id=+g.dataset.node; select(id);
      const n=model.nodes.find(n=>n.id===id);
      const p=toLocal(e.clientX,e.clientY);
      dragging={id, dx:n.x-p.x, dy:n.y-p.y}; }
    else { select(null);
      dragging={pan:true, sx:e.clientX, sy:e.clientY, px:pan.x, py:pan.y}; }
  }
  function onMove(e){
    if(!dragging) return;
    if(dragging.pan){ pan.x=dragging.px+(e.clientX-dragging.sx); pan.y=dragging.py+(e.clientY-dragging.sy);
      applyView(); return; }
    const n=model.nodes.find(n=>n.id===dragging.id); if(!n) return;
    const p=toLocal(e.clientX,e.clientY);
    n.x=snap(p.x+dragging.dx); n.y=snap(p.y+dragging.dy);
    render();
  }
  function toLocal(cx,cy){ const r=svg.getBoundingClientRect();
    return {x:(cx-r.left-pan.x)/pan.scale, y:(cy-r.top-pan.y)/pan.scale}; }
  function snap(v){ return Math.round(v/12)*12; }

  /* ---- model ops ------------------------------------------------------- */
  function addNode(type,x,y){
    const sym=SYMBOLS[type];
    const n={id:idSeq++, type, x, y, label:sym.name, ioa:null, state:null, rot:0};
    model.nodes.push(n); select(n.id); render(); inspect();
  }
  function deleteSelected(){
    if(selected==null) return;
    model.nodes=model.nodes.filter(n=>n.id!==selected);
    model.wires=model.wires.filter(w=>w.a!==selected&&w.b!==selected);
    selected=null; render(); inspect();
  }
  function select(id){ selected=id; render(); inspect(); }
  function highlight(id,on){ render(); }

  /* ---- render ---------------------------------------------------------- */
  function render(){
    // wires
    gWires.innerHTML='';
    const energized = n => n && (n.state===2 || n.state===true || n.state==='ON');
    for(const w of model.wires){
      const a=model.nodes.find(n=>n.id===w.a), b=model.nodes.find(n=>n.id===w.b);
      if(!a||!b) continue;
      const live = energized(a) || energized(b);
      const line=mk('path',{d:`M ${a.x} ${a.y} L ${b.x} ${b.y}`});
      if(live){ line.setAttribute('class','wire-energized'); }
      else { line.setAttribute('stroke','#4a6075'); line.setAttribute('fill','none');
        line.setAttribute('stroke-width','2.5'); line.setAttribute('stroke-linecap','round'); }
      gWires.appendChild(line);
    }
    // nodes
    gNodes.innerHTML='';
    for(const n of model.nodes){
      const sym=SYMBOLS[n.type];
      const g=mk('g',{transform:`translate(${n.x} ${n.y}) rotate(${n.rot||0})`,
        'data-node':n.id,filter:'url(#bevel)',style:'cursor:pointer'});
      let label=null;
      if(sym.meas && n.ioa!=null){ const p=appState.points.get(n.ioa);
        label=p?p.display:'---'; }
      g.innerHTML=sym.draw(n.state, label);
      // bind badge / label
      if(n.ioa!=null){
        const t=mk('text',{x:0,y:sym.name==='Busbar'?-12:42,'text-anchor':'middle',
          fill:'#35d0e0','font-size':10,'font-family':'IBM Plex Mono'});
        t.textContent='IOA '+n.ioa; g.appendChild(t);
      }
      if(n.label && n.type!=='node'){
        const lt=mk('text',{x:0,y:sym.name==='Busbar'?-14:-36,'text-anchor':'middle',
          fill:'#90a4b4','font-size':10}); lt.textContent=n.label; g.appendChild(lt);
      }
      if(n.id===selected){
        const bb=mk('rect',{x:-40,y:-40,width:80,height:80,rx:8,fill:'none',
          stroke:'#35d0e0','stroke-width':1.5,'stroke-dasharray':'4 4'});
        g.insertBefore(bb, g.firstChild);
      }
      gNodes.appendChild(g);
    }
  }

  /* ---- inspector ------------------------------------------------------- */
  function inspect(){
    const host=document.getElementById('sldInspectorBody');
    if(selected==null){ host.className='empty'; host.style.height='auto'; host.style.padding='30px 0';
      host.innerHTML=`<div>Select an element to edit its properties and bind it to a live IOA.</div>`;
      return; }
    host.className=''; host.style.padding='0';
    const n=model.nodes.find(x=>x.id===selected); const sym=SYMBOLS[n.type];
    host.innerHTML=`
      <div class="field"><label>Element</label>
        <input value="${sym.name}" disabled></div>
      <div class="field"><label>Label</label>
        <input id="inLabel" value="${n.label||''}"></div>
      <div class="field"><label>Rotation</label>
        <select id="inRot"><option value="0">0°</option><option value="90">90°</option>
          <option value="180">180°</option><option value="270">270°</option></select></div>
      ${sym.live?`<div class="field"><label>Bind to IOA (live)</label>
        <input id="inIoa" type="number" value="${n.ioa!=null?n.ioa:''}" placeholder="e.g. 1001"></div>
        <div class="field"><label>Preview state</label>
        <select id="inState"><option value="">— live —</option><option value="2">Closed / ON</option>
          <option value="1">Open / OFF</option></select></div>`:''}
      <button class="btn sm danger" id="inDel" style="width:100%;margin-top:6px">Delete element</button>`;
    document.getElementById('inRot').value=String(n.rot||0);
    document.getElementById('inLabel').oninput=e=>{ n.label=e.target.value; render(); };
    document.getElementById('inRot').onchange=e=>{ n.rot=+e.target.value; render(); };
    if(sym.live){
      document.getElementById('inIoa').oninput=e=>{ n.ioa=e.target.value===''?null:+e.target.value;
        updateBinding(appState.points.get(n.ioa)); render(); };
      document.getElementById('inState').onchange=e=>{ n.state=e.target.value===''?null:+e.target.value; render(); };
    }
    document.getElementById('inDel').onclick=deleteSelected;
  }

  /* ---- live binding ---------------------------------------------------- */
  function updateBinding(p){
    if(!p) return;
    let touched=false;
    for(const n of model.nodes){
      if(n.ioa===p.ioa){
        if(SYMBOLS[n.type].meas) n._mv=p.display;
        else n.state = p.value;
        touched=true;
      }
    }
    if(touched) render();
  }

  /* ---- persistence ----------------------------------------------------- */
  async function saveDiagram(){
    const all=await fetch('/api/sld').then(r=>r.json()).catch(()=>({diagrams:{}}));
    all.diagrams = all.diagrams||{};
    all.diagrams['default'] = model;
    await fetch('/api/sld',{method:'POST',headers:{'content-type':'application/json'},
      body:JSON.stringify(all)});
    flash('Diagram saved');
  }
  async function loadDiagram(silent){
    const all=await fetch('/api/sld').then(r=>r.json()).catch(()=>({diagrams:{}}));
    const d=(all.diagrams||{})['default'];
    if(d && d.nodes){ model=d; idSeq=Math.max(1,...model.nodes.map(n=>n.id))+1; render();
      if(!silent) flash('Diagram loaded'); }
    else if(!silent) flash('No saved diagram');
  }
  function flash(msg){ const h=document.getElementById('sldHint'); const old=h.textContent;
    h.textContent=msg; setTimeout(()=>h.textContent=old,1800); }

  /* ---- view ------------------------------------------------------------ */
  function resize(){ const w=svg.parentElement; viewW=w.clientWidth; viewH=w.clientHeight;
    svg.setAttribute('viewBox',`0 0 ${viewW} ${viewH}`);
    svg.setAttribute('width',viewW); svg.setAttribute('height',viewH); applyView(); }
  function applyView(){ [gWires,gNodes,gOverlay].forEach(g=>
    g.setAttribute('transform',`translate(${pan.x} ${pan.y}) scale(${pan.scale})`)); }

  function reload(){ loadDiagram(true); }
  return {init, resize, updateBinding, reload};
})();
window.SLD=SLD;
