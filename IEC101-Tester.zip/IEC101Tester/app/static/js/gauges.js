/* =========================================================================
   Gauges & sparklines — lightweight canvas instrumentation for the Overview
   ========================================================================= */
'use strict';

const Gauges = (function(){
  // draw a 270° arc gauge on a canvas
  function drawGauge(canvas, value, min, max, color){
    const dpr = window.devicePixelRatio || 1;
    const size = 150;
    canvas.width = size*dpr; canvas.height = size*dpr;
    const ctx = canvas.getContext('2d'); ctx.scale(dpr,dpr);
    const cx=size/2, cy=size/2, r=58;
    const start=Math.PI*0.75, end=Math.PI*2.25;
    const frac=Math.max(0,Math.min(1,(value-min)/(max-min)));
    ctx.clearRect(0,0,size,size);
    // track
    ctx.beginPath(); ctx.arc(cx,cy,r,start,end);
    ctx.strokeStyle='#1c2a38'; ctx.lineWidth=11; ctx.lineCap='round'; ctx.stroke();
    // value arc with glow
    ctx.beginPath(); ctx.arc(cx,cy,r,start,start+(end-start)*frac);
    ctx.strokeStyle=color; ctx.lineWidth=11; ctx.lineCap='round';
    ctx.shadowColor=color; ctx.shadowBlur=12; ctx.stroke(); ctx.shadowBlur=0;
    // ticks
    ctx.strokeStyle='#2a3b4a'; ctx.lineWidth=1.5;
    for(let i=0;i<=10;i++){
      const a=start+(end-start)*(i/10);
      ctx.beginPath();
      ctx.moveTo(cx+Math.cos(a)*(r+9), cy+Math.sin(a)*(r+9));
      ctx.lineTo(cx+Math.cos(a)*(r+13), cy+Math.sin(a)*(r+13));
      ctx.stroke();
    }
  }

  // draw a small inline sparkline into a canvas element
  function drawSpark(canvas, data, color){
    const w=70,h=22,dpr=window.devicePixelRatio||1;
    canvas.width=w*dpr; canvas.height=h*dpr;
    const ctx=canvas.getContext('2d'); ctx.scale(dpr,dpr);
    ctx.clearRect(0,0,w,h);
    if(data.length<2) return;
    const mn=Math.min(...data), mx=Math.max(...data), rng=(mx-mn)||1;
    ctx.beginPath();
    data.forEach((v,i)=>{
      const x=(i/(data.length-1))*w;
      const y=h-2-((v-mn)/rng)*(h-4);
      i?ctx.lineTo(x,y):ctx.moveTo(x,y);
    });
    ctx.strokeStyle=color||'#35d0e0'; ctx.lineWidth=1.4; ctx.stroke();
    // last point dot
    const lx=w, ly=h-2-((data[data.length-1]-mn)/rng)*(h-4);
    ctx.beginPath(); ctx.arc(lx-1,ly,1.8,0,7); ctx.fillStyle=color||'#35d0e0'; ctx.fill();
  }

  // draw the active-power trend line chart
  function drawTrend(canvas, data, color){
    const parent=canvas.parentElement;
    const w=parent.clientWidth, h=150, dpr=window.devicePixelRatio||1;
    canvas.width=w*dpr; canvas.height=h*dpr;
    const ctx=canvas.getContext('2d'); ctx.scale(dpr,dpr);
    ctx.clearRect(0,0,w,h);
    // grid
    ctx.strokeStyle='#15212c'; ctx.lineWidth=1;
    for(let i=0;i<=4;i++){ const y=(h/4)*i+.5; ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke(); }
    if(data.length<2) return;
    const mn=Math.min(...data), mx=Math.max(...data), rng=(mx-mn)||1;
    const pad=10;
    // area fill
    const grad=ctx.createLinearGradient(0,0,0,h);
    grad.addColorStop(0,'rgba(53,208,224,.25)'); grad.addColorStop(1,'rgba(53,208,224,0)');
    ctx.beginPath();
    data.forEach((v,i)=>{ const x=(i/(data.length-1))*w;
      const y=pad+(1-(v-mn)/rng)*(h-2*pad); i?ctx.lineTo(x,y):ctx.moveTo(x,y); });
    ctx.lineTo(w,h); ctx.lineTo(0,h); ctx.closePath(); ctx.fillStyle=grad; ctx.fill();
    // line
    ctx.beginPath();
    data.forEach((v,i)=>{ const x=(i/(data.length-1))*w;
      const y=pad+(1-(v-mn)/rng)*(h-2*pad); i?ctx.lineTo(x,y):ctx.moveTo(x,y); });
    ctx.strokeStyle=color||'#35d0e0'; ctx.lineWidth=2;
    ctx.shadowColor=color||'#35d0e0'; ctx.shadowBlur=8; ctx.stroke(); ctx.shadowBlur=0;
  }

  return {drawGauge, drawSpark, drawTrend};
})();
window.Gauges=Gauges;
