/* =========================================================================
   IEC 60870-5-101 Tester — frontend application logic
   ========================================================================= */
'use strict';

const API = (p, opt) => fetch('/api' + p, opt).then(r => r.json());
const POST = (p, body) => API(p, {method:'POST', headers:{'content-type':'application/json'},
  body: JSON.stringify(body || {})});
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const el = (t, c, h) => { const e = document.createElement(t); if(c)e.className=c; if(h!=null)e.innerHTML=h; return e; };

const State = {
  running:false, points:new Map(), trace:[], paused:false,
  traceFilter:'all', monFilter:'all', monSearch:'', selectedIoa:null,
  logFilters:new Set(['info','warn','error']), typeMeta:{},
  history:new Map(),          // ioa -> [values] for sparklines/gauges
  powerTrend:[],              // active-power history for the trend chart
  licensed:false, license:null,
};

/* ---- toast -------------------------------------------------------------- */
function toast(title, desc, kind){
  const t = el('div','toast ' + (kind||''));
  t.appendChild(el('div','tt', title));
  if(desc) t.appendChild(el('div','td', desc));
  $('#toasts').appendChild(t);
  setTimeout(()=>{ t.style.opacity='0'; t.style.transform='translateX(30px)';
    setTimeout(()=>t.remove(),250); }, 3600);
}

/* ---- navigation --------------------------------------------------------- */
$$('.navbtn').forEach(b => b.addEventListener('click', () => {
  $$('.navbtn').forEach(x=>x.classList.remove('active'));
  b.classList.add('active');
  $$('.view').forEach(v=>v.classList.remove('active'));
  $('#view-' + b.dataset.view).classList.add('active');
  if(b.dataset.view==='sld' && window.SLD) SLD.resize();
  if(b.dataset.view==='overview') renderOverview();
  if(b.dataset.view==='monitor') renderMonitor();
  if(b.dataset.view==='config') loadConfigView();
}));

/* ---- WebSocket ---------------------------------------------------------- */
let ws;
function connectWS(){
  ws = new WebSocket((location.protocol==='https:'?'wss':'ws')+'://'+location.host+'/ws');
  ws.onopen = () => { setInterval(()=>{ if(ws.readyState===1) ws.send('ping'); }, 15000); };
  ws.onclose = () => setTimeout(connectWS, 1500);
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if(m.type==='trace') onTrace(m.data);
    else if(m.type==='points') m.data.forEach(applyPoint);
    else if(m.type==='points_full'){ State.points.clear(); m.data.forEach(applyPoint); renderMonitor(); }
    else if(m.type==='status') applyStatus(m.data);
  };
}

/* ---- status ------------------------------------------------------------- */
function applyStatus(s){
  State.running = s.running;
  $('#sbDot').className = 'dot ' + (s.link_up ? 'up pulse' : (s.running?'down':''));
  $('#sbLink').textContent = s.link_up ? 'Link up' : (s.running?'Connecting…':'Disconnected');
  $('#sbMode').textContent = s.mode || '—';
  $('#sbPts').textContent = s.points || 0;
  const st = s.stats||{};
  $('#sbTx').textContent = st.tx_frames||0;
  $('#sbRx').textContent = st.rx_frames||0;
  $('#sbArx').textContent = st.rx_asdu||0;
  $('#sbTo').textContent = st.timeouts||0;
  $('#sbErr').textContent = st.errors||0;
  $('#btnStart').disabled = s.running;
  $('#btnStop').disabled = !s.running;
}
setInterval(()=>{ if(State.running) API('/status').then(applyStatus); }, 1500);

/* ========================================================================
   MONITOR
   ======================================================================== */
function applyPoint(p){
  const prev = State.points.get(p.ioa);
  p._changed = prev && prev.value !== p.value;
  if(prev && prev.name && !p.name) p.name = prev.name;   // keep local label
  State.points.set(p.ioa, p);
  // track numeric history for sparklines / gauges
  if(typeof p.value === 'number' && (p.type_name||'').startsWith('M_ME')){
    let h = State.history.get(p.ioa); if(!h){ h=[]; State.history.set(p.ioa,h); }
    h.push(p.value); if(h.length>60) h.shift();
  }
  if(window.SLD) SLD.updateBinding(p);
}
function classifyPoint(p){
  const t = p.type_name||'';
  if(t.startsWith('M_SP')||t.startsWith('M_DP')||t.startsWith('M_ST')) return 'status';
  if(t.startsWith('M_ME')) return 'measured';
  if(t.startsWith('M_IT')) return 'counter';
  return 'other';
}
function valueBadge(p){
  const t = p.type_name||'';
  if(t.startsWith('M_DP')){
    const cls = p.value===2?'on':p.value===1?'off':'mid';
    return `<span class="badge ${cls}">${p.display}</span>`;
  }
  if(t.startsWith('M_SP')){
    return `<span class="badge ${p.value?'on':'off'}">${p.display}</span>`;
  }
  return `<span class="val">${p.display}</span>`;
}
function renderMonitor(){
  const body = $('#monBody'); if(!body) return;
  if(State.editingName) return;   // don't clobber an open name editor
  const q = State.monSearch.toLowerCase();
  const rows = [...State.points.values()]
    .filter(p => State.monFilter==='all' || classifyPoint(p)===State.monFilter)
    .filter(p => !q || String(p.ioa).includes(q) || (p.name||'').toLowerCase().includes(q)
      || (p.type_name||'').toLowerCase().includes(q))
    .sort((a,b)=>a.ioa-b.ioa);
  body.innerHTML = '';
  for(const p of rows){
    const mon = (p.type_name||'').startsWith('M_');
    const measured = (p.type_name||'').startsWith('M_ME');
    const tr = el('tr', p._changed?'flash':'');
    tr.innerHTML = `
      <td>${p.ioa}</td>
      <td class="name-cell" data-ioa="${p.ioa}">${p.name||'<span style="color:var(--txt-mut)">— click to name</span>'}</td>
      <td><span class="badge ${mon?'mon':'ctl'}">${p.type_name||p.expected_type_name||'—'}</span>${p.type_mismatch?`<span class="badge mid" title="Expected ${p.expected_type_name}, received ${p.type_name}">⚠ type</span>`:''}${!p.received&&p.expected_type_name?'<span class="badge" style="color:var(--txt-mut)">defined</span>':''}</td>
      <td>${valueBadge(p)}${measured?`<canvas class="spark" width="70" height="22" data-spark="${p.ioa}"></canvas>`:''}</td>
      <td class="${p.quality?'q-bad':'q-good'}">${p.quality_text}</td>
      <td style="color:var(--txt-dim)">${p.cot_name||''}</td>
      <td style="color:var(--txt-mut)">${p.count||0}</td>
      <td style="color:var(--txt-mut)">${p.time?p.time.split('T')[1]:(p.updated?p.updated.split('T')[1]:'')}</td>`;
    tr.querySelector('.name-cell').addEventListener('click', e=>{ e.stopPropagation(); editName(p.ioa, e.currentTarget); });
    tr.addEventListener('click', ()=>{ State.selectedIoa=p.ioa;
      $$('#monBody tr').forEach(r=>r.style.outline=''); tr.style.outline='1px solid var(--cyan)'; });
    body.appendChild(tr);
    p._changed=false;
  }
  // tiles
  const pts=[...State.points.values()];
  const tiles=[
    ['Total points', pts.length, 'cyan'],
    ['Status pts', pts.filter(p=>classifyPoint(p)==='status').length, ''],
    ['Measured', pts.filter(p=>classifyPoint(p)==='measured').length, ''],
    ['Breakers closed', pts.filter(p=>p.type_name&&p.type_name.startsWith('M_DP')&&p.value===2).length, 'green'],
    ['Invalid quality', pts.filter(p=>p.quality).length, 'amber'],
  ];
  $('#monTiles').innerHTML = tiles.map(([k,v,c])=>
    `<div class="tile"><div class="k">${k}</div><div class="v ${c}">${v}</div></div>`).join('');
  // sparklines
  $$('#monBody canvas[data-spark]').forEach(cv=>{
    const h=State.history.get(+cv.dataset.spark)||[];
    if(window.Gauges) Gauges.drawSpark(cv, h, '#35d0e0');
  });
}
setInterval(()=>{ if($('#view-monitor').classList.contains('active')) renderMonitor(); }, 1000);

/* editable point names (persisted into the project) */
function editName(ioa, cell){
  State.editingName = true;
  const cur = (State.points.get(ioa)||{}).name || '';
  cell.innerHTML = `<input value="${cur.replace(/"/g,'&quot;')}">`;
  const inp = cell.querySelector('input'); inp.focus(); inp.select();
  let done=false;
  const finish = (save)=>{
    if(done) return; done=true; State.editingName=false;
    if(save){ const name=inp.value.trim(); const p=State.points.get(ioa);
      if(p) p.name=name; POST('/api/points/names', {names:{[ioa]:name}}); }
    renderMonitor();
  };
  inp.addEventListener('keydown', e=>{ if(e.key==='Enter'){e.preventDefault();finish(true);}
    if(e.key==='Escape') finish(false); });
  inp.addEventListener('blur', ()=>finish(true));
}

$('#monSearch').addEventListener('input', e=>{ State.monSearch=e.target.value; renderMonitor(); });
$$('#monFilters .chip').forEach(c=>c.addEventListener('click', ()=>{
  $$('#monFilters .chip').forEach(x=>x.classList.remove('on')); c.classList.add('on');
  State.monFilter=c.dataset.f; renderMonitor(); }));
$('#btnReadSel').addEventListener('click', ()=>{
  if(!State.selectedIoa) return toast('No selection','Click a row first','err');
  sendCommand('read', {ioa:State.selectedIoa});
});

/* ========================================================================
   TRACER
   ======================================================================== */
function onTrace(d){
  State.trace.push(d);
  if(State.trace.length>6000) State.trace.splice(0, State.trace.length-6000);
  if(d.kind==='log' || d.kind==='state') pushLog(d);
  if(!State.paused && (d.kind==='frame')) appendTraceRow(d);
}
function traceMatch(d){
  const f=State.traceFilter;
  if(f==='all') return true;
  if(f==='tx') return d.direction==='tx';
  if(f==='rx') return d.direction==='rx';
  if(f==='asdu') return !!d.asdu;
  if(f==='frame') return !d.asdu;
  return true;
}
function asduTag(d){
  if(!d.asdu) return `<span class="tag frame">${d.frame?d.frame.kind:'frame'}</span>`;
  const ctl = d.asdu.type_id>=45 && d.asdu.type_id<70 || d.asdu.type_id>=100;
  return `<span class="tag ${ctl?'asdu-ctl':'asdu-mon'}">${d.asdu.type_name}</span>`;
}
function traceSummary(d){
  const fr=d.frame||{};
  let s = asduTag(d);
  if(d.asdu){
    s += `COT=${d.asdu.cot_name} CA=${d.asdu.common_address} · ${d.asdu.objects.length} obj`;
    const o=d.asdu.objects[0];
    if(o) s += ` · IOA ${o.ioa}=${fmtVal(o.value)}`;
  }else{
    s += `fn=${fr.function} ${fr.prm?'PRM':'SEC'}${fr.fcb?' FCB':''}${fr.acd?' ACD':''} addr=${fr.address}`;
  }
  return s;
}
function fmtVal(v){ return typeof v==='number'? (Number.isInteger(v)?v:v.toFixed(3)) : v; }

function appendTraceRow(d){
  if(!traceMatch(d)) return;
  const list=$('#traceList');
  const row=el('div','trace-row');
  row.innerHTML = `<div class="ts">${(d.ts||'').split('T')[1]||''}</div>
    <div class="dir ${d.direction}">${(d.direction||'').toUpperCase()}</div>
    <div><div class="summary">${traceSummary(d)}</div>
      <div class="hex">${d.hex||''}</div></div>`;
  row.addEventListener('click', ()=>{ $$('.trace-row').forEach(r=>r.classList.remove('sel'));
    row.classList.add('sel'); showDetail(d); });
  list.appendChild(row);
  while(list.children.length>1500) list.removeChild(list.firstChild);
  if($('#traceAuto').checked) list.scrollTop = list.scrollHeight;
}
function rerenderTrace(){
  const list=$('#traceList'); list.innerHTML='';
  State.trace.filter(d=>d.kind==='frame').forEach(appendTraceRow);
}
$$('#traceFilters .chip').forEach(c=>c.addEventListener('click', ()=>{
  $$('#traceFilters .chip').forEach(x=>x.classList.remove('on')); c.classList.add('on');
  State.traceFilter=c.dataset.tf; rerenderTrace(); }));
$('#btnPause').addEventListener('click', e=>{ State.paused=!State.paused;
  e.target.textContent = State.paused?'▶ Resume':'⏸ Pause'; if(!State.paused) rerenderTrace(); });
$('#btnClearTrace').addEventListener('click', ()=>{ State.trace=[]; $('#traceList').innerHTML='';
  POST('/trace/clear'); $('#traceDetail').classList.remove('open'); });
$('#btnExportTrace').addEventListener('click', exportTrace);

/* byte-level decode drawer */
function showDetail(d){
  const det=$('#traceDetail'); det.classList.add('open');
  const bytes = (d.hex||'').split(' ').filter(Boolean);
  const cls = classifyBytes(d, bytes.length);
  let bh = '<div class="bytes">';
  bytes.forEach((b,i)=>{ bh += `<div class="byte ${cls[i]||''}"><span class="bi">${i}</span>${b}</div>`; });
  bh += '</div>';
  let dl = '<dl>';
  const add=(k,v)=>{ dl+=`<dt>${k}</dt><dd>${v}</dd>`; };
  if(d.frame){
    add('Frame type', d.frame.kind);
    add('Control (C)', '0x'+(d.frame.control||0).toString(16).padStart(2,'0')
      +` — ${d.frame.prm?'PRM=1 (primary)':'PRM=0 (secondary)'}`);
    add('Function code', d.frame.function + ' ' + fnName(d.frame));
    if(d.frame.prm){ add('FCB / FCV', `${d.frame.fcb?1:0} / ${d.frame.fcv?1:0}`); }
    else{ add('ACD / DFC', `${d.frame.acd?1:0} / ${d.frame.dfc?1:0}`); }
    add('Link address', d.frame.address);
  }
  if(d.asdu){
    const a=d.asdu;
    add('Type ID', `${a.type_id} (${a.type_name})`);
    add('Cause (COT)', `${a.cot} — ${a.cot_name}${a.negative?' · NEGATIVE':''}${a.test?' · TEST':''}`);
    add('Originator', a.originator);
    add('Common address', a.common_address);
    add('Structure', a.sq?'SQ=1 (sequence)':'SQ=0 (individual)');
    add('Objects', a.objects.map(o=>{
      let s=`IOA ${o.ioa} = ${fmtVal(o.value)}`;
      if(o.quality) s+=` [${o.quality_text}]`;
      if(o.time) s+=` @ ${o.time.split('T')[1]}`;
      return s;
    }).join('<br>'));
  }
  dl+='</dl>';
  det.innerHTML = `<div style="color:var(--cyan);font-size:12px;letter-spacing:.05em;margin-bottom:4px">
    FRAME DECODE · ${bytes.length} bytes · ${(d.ts||'').split('T')[1]}</div>` + bh + dl;
}
function fnName(fr){
  const prm={0:'reset link',1:'reset user',2:'test link',3:'user data (conf)',
    4:'user data',8:'req access',9:'req link status',10:'req class-1',11:'req class-2'};
  const sec={0:'ACK',1:'NACK',8:'user data',9:'NACK no data',11:'link status',14:'not funct',15:'not impl'};
  return '('+((fr.prm?prm:sec)[fr.function]||'?')+')';
}
function classifyBytes(d, n){
  // map each byte index to a role for colour coding
  const c={}; const bytes=(d.hex||'').split(' ').filter(Boolean);
  if(!bytes.length) return c;
  const first=parseInt(bytes[0],16);
  const alen=(d.frame&&d.frame.address>255)?2:((State.points.size,2)); // best effort
  if(first===0x10){ c[0]='start'; c[1]='ctrl';
    for(let i=0;i<alen;i++) c[2+i]='addr'; c[2+alen]='cs'; c[3+alen]='start'; }
  else if(first===0x68){ c[0]='start';c[1]='';c[2]='';c[3]='start'; c[4]='ctrl';
    for(let i=0;i<alen;i++) c[5+i]='addr';
    for(let i=5+alen;i<n-2;i++) c[i]='asdu';
    c[n-2]='cs'; c[n-1]='start'; }
  else if(first===0xe5||first===0xa2){ c[0]='start'; }
  return c;
}
function exportTrace(){
  const lines = State.trace.filter(d=>d.kind==='frame').map(d=>
    `${d.ts}\t${(d.direction||'').toUpperCase()}\t${traceSummary(d).replace(/<[^>]+>/g,'')}\t${d.hex||''}`);
  const blob=new Blob([lines.join('\n')],{type:'text/plain'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob);
  a.download='iec101-trace.txt'; a.click();
}

/* ========================================================================
   LOG
   ======================================================================== */
function pushLog(d){
  let lvl = (d.level||'info'); if(lvl==='warning') lvl='warn';
  const line={ts:d.ts, level:lvl, text:d.text || (d.kind==='state'?('LINK '+d.text):'')};
  if(!State.logFilters.has(lvl)) { renderLogLine(line, true); return; }
  renderLogLine(line);
}
function renderLogLine(line, hidden){
  const c=$('#logConsole');
  const e=el('div','logline '+line.level + (hidden?' hidden':''));
  e.innerHTML = `<span class="t">${(line.ts||'').split('T')[1]||''}</span>  ${line.text}`;
  e.dataset.level=line.level;
  c.appendChild(e);
  while(c.children.length>3000) c.removeChild(c.firstChild);
  c.scrollTop=c.scrollHeight;
}
$$('#logFilters .chip').forEach(c=>c.addEventListener('click', ()=>{
  c.classList.toggle('on');
  const lv=c.dataset.lf;
  if(c.classList.contains('on')) State.logFilters.add(lv); else State.logFilters.delete(lv);
  $$('#logConsole .logline').forEach(l=>{
    l.classList.toggle('hidden', !State.logFilters.has(l.dataset.level)); });
}));
$('#btnClearLog').addEventListener('click', ()=>$('#logConsole').innerHTML='');

/* ========================================================================
   COMMAND BUILDER
   ======================================================================== */
const CMD_DEFS = [
  {kind:'interrogation', title:'General Interrogation', desc:'C_IC_NA_1 — read the full station image.',
   fields:[{k:'group',label:'Group',type:'select',opts:[['20','Station (global)'],['21','Group 1'],['22','Group 2'],['23','Group 3']],def:'20'}], btn:'Interrogate', cls:''},
  {kind:'counter_interrogation', title:'Counter Interrogation', desc:'C_CI_NA_1 — freeze & read integrated totals.',
   fields:[{k:'qcc',label:'QCC',type:'select',opts:[['5','General request + freeze'],['1','Group 1'],['69','Read w/o freeze']],def:'5'}], btn:'Read counters', cls:''},
  {kind:'clock_sync', title:'Clock Synchronisation', desc:'C_CS_NA_1 — set the gateway clock to PC time.',
   fields:[], btn:'Synchronise clock', cls:''},
  {kind:'read', title:'Read Command', desc:'C_RD_NA_1 — poll a single information object.',
   fields:[{k:'ioa',label:'IOA',type:'number',def:'1001'}], btn:'Read', cls:''},
  {kind:'single', title:'Single Command', desc:'C_SC_NA_1 — ON/OFF command (1 bit).',
   fields:[{k:'ioa',label:'IOA',type:'number',def:'1006'},
     {k:'on',label:'State',type:'select',opts:[['true','ON'],['false','OFF']],def:'true'},
     {k:'select',label:'Procedure',type:'select',opts:[['false','Direct execute'],['true','Select before operate']],def:'false'}],
   btn:'Send', cls:'amber'},
  {kind:'double', title:'Double Command', desc:'C_DC_NA_1 — breaker/disconnector OPEN/CLOSE.',
   fields:[{k:'ioa',label:'IOA',type:'number',def:'1001'},
     {k:'state',label:'State',type:'select',opts:[['2','CLOSE (ON)'],['1','OPEN (OFF)']],def:'2'},
     {k:'select',label:'Procedure',type:'select',opts:[['false','Direct execute'],['true','Select before operate']],def:'false'}],
   btn:'Operate', cls:'amber'},
  {kind:'regulating', title:'Regulating Step', desc:'C_RC_NA_1 — tap changer raise/lower.',
   fields:[{k:'ioa',label:'IOA',type:'number',def:'1008'},
     {k:'higher',label:'Direction',type:'select',opts:[['true','Raise (higher)'],['false','Lower']],def:'true'}],
   btn:'Step', cls:'amber'},
  {kind:'setpoint_float', title:'Setpoint (short float)', desc:'C_SE_NC_1 — analog setpoint.',
   fields:[{k:'ioa',label:'IOA',type:'number',def:'2001'},{k:'value',label:'Value',type:'number',def:'0'}],
   btn:'Set', cls:'amber'},
  {kind:'setpoint_scaled', title:'Setpoint (scaled)', desc:'C_SE_NB_1 — scaled integer setpoint.',
   fields:[{k:'ioa',label:'IOA',type:'number',def:'2010'},{k:'value',label:'Value',type:'number',def:'0'}],
   btn:'Set', cls:'amber'},
  {kind:'test', title:'Test Command', desc:'C_TS_NA_1 — link/application liveness test.',
   fields:[], btn:'Send test', cls:''},
];
function buildCommandUI(){
  const grid=$('#cmdGrid'); grid.innerHTML='';
  for(const def of CMD_DEFS){
    const card=el('div','cmd-card');
    card.innerHTML=`<h3>${def.title}</h3><div class="desc">${def.desc}</div>`;
    const inputs={};
    for(const f of def.fields){
      const field=el('div','field'); field.appendChild(el('label',null,f.label));
      let inp;
      if(f.type==='select'){ inp=el('select'); f.opts.forEach(([v,t])=>{
        const o=el('option'); o.value=v; o.textContent=t; if(v===f.def)o.selected=true; inp.appendChild(o); }); }
      else { inp=el('input'); inp.type=f.type; inp.value=f.def; }
      field.appendChild(inp); card.appendChild(field); inputs[f.k]=f;
      inp.dataset.key=f.k; inp.dataset.type=f.type;
    }
    const btn=el('button','btn '+(def.cls||'')+' ', def.btn); btn.style.width='100%';
    btn.addEventListener('click', ()=>{
      const params={};
      card.querySelectorAll('[data-key]').forEach(inp=>{
        let v=inp.value;
        if(v==='true') v=true; else if(v==='false') v=false;
        else if(inp.dataset.type==='number') v=Number(v);
        params[inp.dataset.key]=v;
      });
      sendCommand(def.kind, params);
    });
    card.appendChild(btn);
    grid.appendChild(card);
  }
}
async function sendCommand(kind, params){
  const r = await POST('/command', {kind, params});
  if(r.ok) toast('Command sent', `${r.result.type_name} · ${JSON.stringify(params)}`, 'ok');
  else toast('Command failed', r.error, 'err');
}

/* ========================================================================
   CONNECTION
   ======================================================================== */
let MODE='simulator';
$$('#modeSeg button').forEach(b=>b.addEventListener('click', ()=>{
  $$('#modeSeg button').forEach(x=>x.classList.remove('on')); b.classList.add('on');
  MODE=b.dataset.mode;
  $('#serialFields').classList.toggle('hidden', MODE!=='serial');
  if(MODE==='serial') loadPorts();
}));
async function loadPorts(){
  const r=await API('/ports'); const sel=$('#port'); sel.innerHTML='';
  if(!r.ports.length){ sel.appendChild(el('option',null,'No ports found')); return; }
  r.ports.forEach(p=>{ const o=el('option'); o.value=p.device;
    o.textContent=`${p.device} — ${p.description}`; sel.appendChild(o); });
}
$('#refreshPorts').addEventListener('click', loadPorts);

function gatherConfig(){
  return {
    mode:MODE, port:$('#port').value||'COM1', baudrate:+$('#baudrate').value,
    parity:$('#parity').value, bytesize:+$('#bytesize').value, stopbits:+$('#stopbits').value,
    link_address:+$('#link_address').value, link_addr_len:+$('#link_addr_len').value,
    common_address:+$('#common_address').value, common_len:+$('#common_len').value,
    cot_len:+$('#cot_len').value, ioa_len:+$('#ioa_len').value,
    balanced:$('#balanced').value==='true', poll_interval:+$('#poll_interval').value,
  };
}
$('#btnStart').addEventListener('click', async ()=>{
  await POST('/config', gatherConfig());
  const r=await POST('/start');
  if(r.ok){ toast('Session started', 'Link is coming up…', 'ok'); applyStatus(r.status); }
  else toast('Start failed', r.error, 'err');
});
$('#btnStop').addEventListener('click', async ()=>{
  const r=await POST('/stop'); applyStatus(r.status); toast('Session stopped','');
});
$('#btnGI').addEventListener('click', ()=>sendCommand('interrogation',{group:20}));
$('#btnClock').addEventListener('click', ()=>sendCommand('clock_sync',{}));

/* ========================================================================
   CONFIG / PROJECT  (point database + project metadata)
   ======================================================================== */
const DB_TYPES = [
  {g:'Status (single/double/step)', opts:[
    [1,'1 · M_SP_NA_1 single-point'],[3,'3 · M_DP_NA_1 double-point'],
    [5,'5 · M_ST_NA_1 step position'],[30,'30 · M_SP_TB_1 single +time'],
    [31,'31 · M_DP_TB_1 double +time']]},
  {g:'Measured (choose the mode you send)', opts:[
    [9,'9 · M_ME_NA_1 normalized'],[11,'11 · M_ME_NB_1 scaled'],
    [13,'13 · M_ME_NC_1 short float'],[34,'34 · M_ME_TD_1 norm +time'],
    [35,'35 · M_ME_TE_1 scaled +time'],[36,'36 · M_ME_TF_1 float +time']]},
  {g:'Counter / bitstring', opts:[
    [15,'15 · M_IT_NA_1 counter'],[7,'7 · M_BO_NA_1 bitstring32']]},
];
const SAMPLE_DB = [
  {ioa:1001,type_id:3,name:'CB-Q0 Breaker 230kV',unit:'',group:1},
  {ioa:1002,type_id:3,name:'DS-Q1 Disconnector bus-1',unit:'',group:1},
  {ioa:1003,type_id:3,name:'DS-Q2 Disconnector bus-2',unit:'',group:1},
  {ioa:1004,type_id:3,name:'ES-Q8 Earth switch',unit:'',group:1},
  {ioa:1005,type_id:1,name:'Protection trip (86)',unit:'',group:1},
  {ioa:1006,type_id:1,name:'Local/Remote selector',unit:'',group:1},
  {ioa:1008,type_id:5,name:'Transformer tap position',unit:'',group:1},
  {ioa:2001,type_id:13,name:'Voltage L1',unit:'kV',group:2},
  {ioa:2004,type_id:13,name:'Current L1',unit:'A',group:2},
  {ioa:2007,type_id:13,name:'Active power P',unit:'MW',group:2},
  {ioa:2009,type_id:13,name:'Frequency',unit:'Hz',group:2},
  {ioa:2010,type_id:11,name:'Transformer temperature',unit:'0.1°C',group:2},
  {ioa:3001,type_id:15,name:'Energy import',unit:'kWh',group:1},
];
let DB_ROWS = [];   // working copy of the point database

const META_FIELDS = ['project_name','engineer','client','aoc','scc',
                     'station_name','voltage_level','bay','date'];

function typeSelectHtml(sel){
  let h=`<select class="db-type">`;
  for(const grp of DB_TYPES){
    h+=`<optgroup label="${grp.g}">`;
    for(const [v,t] of grp.opts) h+=`<option value="${v}" ${v===sel?'selected':''}>${t}</option>`;
    h+=`</optgroup>`;
  }
  return h+`</select>`;
}
function renderDbTable(){
  const body=$('#dbBody'); body.innerHTML='';
  DB_ROWS.forEach((r,i)=>{
    const tr=el('tr');
    tr.innerHTML=`
      <td><input class="db-ioa" type="number" value="${r.ioa??''}" style="width:78px"></td>
      <td><input class="db-name" value="${(r.name||'').replace(/"/g,'&quot;')}"></td>
      <td>${typeSelectHtml(r.type_id)}</td>
      <td><input class="db-unit" value="${(r.unit||'').replace(/"/g,'&quot;')}" style="width:70px"></td>
      <td><input class="db-group" type="number" value="${r.group||1}" style="width:60px"></td>
      <td><input class="db-desc" value="${(r.desc||'').replace(/"/g,'&quot;')}"></td>
      <td><button class="btn sm danger db-del" title="Delete">✕</button></td>`;
    const upd=()=>{ r.ioa=+tr.querySelector('.db-ioa').value;
      r.name=tr.querySelector('.db-name').value; r.type_id=+tr.querySelector('.db-type').value;
      r.unit=tr.querySelector('.db-unit').value; r.group=+tr.querySelector('.db-group').value;
      r.desc=tr.querySelector('.db-desc').value; };
    tr.querySelectorAll('input,select').forEach(x=>x.addEventListener('change',upd));
    tr.querySelector('.db-del').addEventListener('click',()=>{ DB_ROWS.splice(i,1); renderDbTable(); });
    // style measured rows with the mode
    body.appendChild(tr);
  });
  if(!DB_ROWS.length){
    body.innerHTML=`<tr><td colspan="7" style="text-align:center;color:var(--txt-mut);padding:22px">
      No points defined. Click <b>+ Add point</b> or <b>Load sample</b> to start addressing.</td></tr>`;
  }
}
function readDbFields(){   // pull latest values from inputs into DB_ROWS
  const rows=[...$('#dbBody').querySelectorAll('tr')];
  DB_ROWS = rows.filter(tr=>tr.querySelector('.db-ioa')).map(tr=>({
    ioa:+tr.querySelector('.db-ioa').value,
    name:tr.querySelector('.db-name').value,
    type_id:+tr.querySelector('.db-type').value,
    unit:tr.querySelector('.db-unit').value,
    group:+tr.querySelector('.db-group').value,
    desc:tr.querySelector('.db-desc').value,
  })).filter(r=>!isNaN(r.ioa));
  return DB_ROWS;
}
$('#btnAddPoint').addEventListener('click',()=>{ readDbFields();
  const nextIoa = DB_ROWS.length? Math.max(...DB_ROWS.map(r=>r.ioa))+1 : 1001;
  DB_ROWS.push({ioa:nextIoa,type_id:3,name:'',unit:'',group:1,desc:''}); renderDbTable(); });
$('#btnAddPreset').addEventListener('click',()=>{ DB_ROWS=SAMPLE_DB.map(r=>({...r})); renderDbTable();
  toast('Sample loaded','Demo substation bay added'); });
$('#btnApplyDb').addEventListener('click',async ()=>{
  readDbFields(); await saveMeta();
  const r=await POST('/pointdb',{points:DB_ROWS});
  if(r.ok){ toast('Applied',`${r.count} points configured`,'ok'); renderMonitor(); }
});
function gatherMeta(){ const m={}; META_FIELDS.forEach(f=>m[f]=$('#m_'+f).value); return m; }
function fillMeta(m){ m=m||{}; META_FIELDS.forEach(f=>{ if($('#m_'+f)) $('#m_'+f).value=m[f]||''; }); }
async function saveMeta(){ return POST('/meta',{meta:gatherMeta()}); }
META_FIELDS.forEach(f=>{ const e=$('#m_'+f); if(e) e.addEventListener('change',saveMeta); });

$('#btnNewProject').addEventListener('click',async ()=>{
  if(!confirm('Start a new project? This clears the current configuration, point database and SLD.')) return;
  await POST('/project/new'); DB_ROWS=[]; renderDbTable(); fillMeta({});
  State.points.clear(); if(window.SLD) SLD.reload();
  toast('New project','Configuration cleared','ok');
});
// Config-view project buttons reuse the Link-view handlers
$('#btnCfgSave').addEventListener('click',()=>$('#btnProjSave').click());
$('#btnCfgOpen').addEventListener('click',()=>$('#projFile').click());

async function loadConfigView(){
  const [meta,db]=await Promise.all([API('/meta'),API('/pointdb')]);
  fillMeta(meta.meta); DB_ROWS=(db.points||[]).map(r=>({...r})); renderDbTable();
}

/* report download */
function downloadReport(fmt){
  toast('Generating report', fmt.toUpperCase()+' …');
  const a=document.createElement('a'); a.href='/api/report?format='+fmt; a.click();
}
$('#btnReportPdf').addEventListener('click',()=>downloadReport('pdf'));
$('#btnReportDoc').addEventListener('click',()=>downloadReport('docx'));

/* ========================================================================
   OVERVIEW (gauges + switchgear + trend)
   ======================================================================== */
const GAUGE_SLOTS = [
  {key:'voltage', match:/volt|\bkv\b/i, def:2001, unit:'kV', color:'#3ddc84', min:0,max:1},
  {key:'current', match:/curr|amp|\ba\b/i, def:2004, unit:'A',  color:'#35d0e0', min:0,max:1},
  {key:'power',   match:/active|power|\bmw\b|\bp\b/i, def:2007, unit:'MW', color:'#f5b544', min:0,max:1},
  {key:'freq',    match:/freq|\bhz\b/i, def:2009, unit:'Hz', color:'#9b8cff', min:49,max:51,fixed:true},
];
State.gaugeRange = {};
function pickGaugePoint(slot){
  const meas=[...State.points.values()].filter(p=>(p.type_name||'').startsWith('M_ME'));
  let p = meas.find(x=>x.name && slot.match.test(x.name));
  if(!p) p = State.points.get(slot.def);
  if(!p) p = meas[GAUGE_SLOTS.indexOf(slot)];
  return p;
}
function renderOverview(){
  const grid=$('#gaugeGrid'); if(!grid) return;
  if(!grid.dataset.built){ // build once
    grid.innerHTML = GAUGE_SLOTS.map(s=>`
      <div class="gauge" data-key="${s.key}">
        <canvas></canvas>
        <div class="g-val" data-val="${s.key}">—</div>
        <div class="g-label" data-lbl="${s.key}">${s.key}</div>
      </div>`).join('');
    grid.dataset.built='1';
  }
  for(const slot of GAUGE_SLOTS){
    const p=pickGaugePoint(slot);
    const cell=grid.querySelector(`.gauge[data-key="${slot.key}"]`);
    const cv=cell.querySelector('canvas');
    const v = p && typeof p.value==='number' ? p.value : 0;
    // auto-range
    let rng=State.gaugeRange[slot.key];
    if(slot.fixed){ rng={min:slot.min,max:slot.max}; }
    else{
      if(!rng){ rng={min:v*0.8||0, max:v*1.2||1}; }
      rng.min=Math.min(rng.min, v*0.85); rng.max=Math.max(rng.max, v*1.15);
      if(rng.max-rng.min<1e-6) rng.max=rng.min+1;
    }
    State.gaugeRange[slot.key]=rng;
    if(window.Gauges) Gauges.drawGauge(cv, v, rng.min, rng.max, slot.color);
    cell.querySelector(`[data-val="${slot.key}"]`).innerHTML =
      (p?v.toFixed(slot.key==='freq'?2:1):'—')+` <span class="g-unit">${slot.unit}</span>`;
    cell.querySelector(`[data-lbl="${slot.key}"]`).textContent =
      p ? (p.name || `IOA ${p.ioa}`) : slot.key;
    if(slot.key==='power' && p && typeof p.value==='number'){
      State.powerTrend.push(p.value); if(State.powerTrend.length>80) State.powerTrend.shift();
    }
  }
  // switchgear
  const sw=[...State.points.values()].filter(p=>{
    const t=p.type_name||''; return t.startsWith('M_DP')||t.startsWith('M_SP')||t.startsWith('M_ST'); })
    .sort((a,b)=>a.ioa-b.ioa);
  $('#swStatus').innerHTML = sw.map(p=>{
    let cls='mid', txt=p.display;
    if((p.type_name||'').startsWith('M_DP')) cls=p.value===2?'on':p.value===1?'off':'mid';
    else if((p.type_name||'').startsWith('M_SP')) cls=p.value?'on':'off';
    else cls='mid';
    return `<div class="sw-cell"><span class="sw-ind ${cls}"></span>
      <span class="sw-name">${p.name||('Point '+p.ioa)}</span>
      <span class="sw-ioa">${p.ioa} · ${txt}</span></div>`;
  }).join('') || '<div style="color:var(--txt-mut);padding:10px">Run a General Interrogation to load switchgear status.</div>';
  // trend
  if(window.Gauges) Gauges.drawTrend($('#trendCanvas'), State.powerTrend, '#f5b544');
}
setInterval(()=>{ if($('#view-overview').classList.contains('active')) renderOverview(); }, 1000);

/* ========================================================================
   PROJECT save / open
   ======================================================================== */
$('#btnProjSave').addEventListener('click', async ()=>{
  const proj = await API('/project');
  const blob=new Blob([JSON.stringify(proj,null,2)],{type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob);
  const d=new Date().toISOString().slice(0,10);
  a.download=`iec101-project-${d}.iecproj`; a.click();
  toast('Project saved','Config, point names & SLD exported','ok');
});
$('#btnProjOpen').addEventListener('click', ()=>$('#projFile').click());
$('#projFile').addEventListener('change', async e=>{
  const f=e.target.files[0]; if(!f) return;
  try{
    const data=JSON.parse(await f.text());
    const r=await POST('/project', data);
    if(!r.ok){ toast('Import failed', r.error,'err'); return; }
    // reflect imported config into the form
    const c=r.config;
    $('#link_address').value=c.link_address; $('#common_address').value=c.common_address;
    $('#cot_len').value=c.cot_len; $('#ioa_len').value=c.ioa_len;
    $('#common_len').value=c.common_len; $('#link_addr_len').value=c.link_addr_len;
    $('#poll_interval').value=c.poll_interval;
    if(r.meta) fillMeta(r.meta);
    if(r.point_db){ DB_ROWS=r.point_db.map(x=>({...x})); renderDbTable(); }
    if(window.SLD) SLD.reload();
    renderMonitor();
    toast('Project loaded', `Applied: ${r.applied.join(', ')}`,'ok');
  }catch(err){ toast('Import failed', String(err),'err'); }
  e.target.value='';
});

/* ========================================================================
   LICENSE gate
   ======================================================================== */
async function checkLicense(){
  const st = await API('/license/status');
  State.license = st; State.licensed = !!st.valid;
  $('#machineId').textContent = st.machine || st.this_machine || '—';
  renderLicenseBadge(st);
  const gate=$('#licenseGate'), box=$('#lgateStatus');
  if(st.valid){
    gate.classList.add('hidden');
    const dl = st.days_left;
    box.className='lgate-status ok';
    box.innerHTML=`<div class="big">Licensed to ${st.licensee||'—'}</div>
      ${st.org?st.org+' · ':''}${st.type} license${dl!=null?` · ${dl} day${dl===1?'':'s'} left`:' · perpetual'}`;
  }else{
    gate.classList.remove('hidden');
    box.className='lgate-status '+(st.installed?'err':'warn');
    box.innerHTML=`<div class="big">${st.installed?'License problem':'Activation required'}</div>${st.reason||''}`;
  }
  return st;
}
function renderLicenseBadge(st){
  const b=$('#sbLicense'), t=$('#sbLicText');
  if(st.valid){
    const dl=st.days_left;
    b.className='stat lic-badge '+(dl!=null&&dl<=3?'warn':'ok');
    t.textContent = (st.type?st.type:'licensed') + (dl!=null?` (${dl}d)`:'');
    b.title=`Licensed to ${st.licensee} ${st.org?'· '+st.org:''}`;
  }else{ b.className='stat lic-badge err'; t.textContent='unlicensed'; }
}
$('#btnActivate').addEventListener('click', async ()=>{
  const token=$('#licenseInput').value.trim();
  if(!token) return toast('Enter a key','Paste your license key first','err');
  const r=await POST('/license/activate', {token});
  if(r.ok){ toast('License activated', r.status.licensee||'','ok'); await checkLicense(); }
  else{ toast('Activation failed', r.error,'err');
    $('#lgateStatus').className='lgate-status err';
    $('#lgateStatus').innerHTML=`<div class="big">Activation failed</div>${r.error}`; }
});
$('#btnCopyMid').addEventListener('click', ()=>{
  navigator.clipboard.writeText($('#machineId').textContent).then(()=>toast('Copied','Machine ID copied','ok'));
});
setInterval(checkLicense, 60000);

/* ========================================================================
   BOOT
   ======================================================================== */
async function boot(){
  await checkLicense();
  const meta=await API('/types');
  State.typeMeta=meta;
  buildCommandUI();
  if(window.SLD) SLD.init(State);
  connectWS();
  API('/status').then(applyStatus);
}
boot();
