# -*- coding: utf-8 -*-
"""
License verification for the IEC 60870-5-101 Tester.

Licenses are issued by the vendor with an Ed25519 private key and verified in
the app with the matching public key (embedded below). Because verification is
asymmetric, a customer cannot forge or alter a license without the vendor's
private key.

A license is a single-line token:

    IEC101-1.<payload_b64url>.<signature_b64url>

where payload is canonical JSON:

    {
      "lid":   "unique license id",
      "name":  "licensee full name",
      "org":   "company / organisation",
      "email": "contact email",
      "type":  "trial" | "standard" | "pro" | "site",
      "issued":  "YYYY-MM-DD",
      "expires": "YYYY-MM-DD"  | "never",
      "machine": "XXXX-XXXX-XXXX" | ""   (empty = any machine / floating),
      "seats":  1,
      "note":   "free text"
    }

The app refuses to run without a valid, unexpired, machine-matching license.
"""

import os
import json
import base64
import hashlib
import uuid
import platform
import datetime

# ---------------------------------------------------------------------------
# Vendor public key (Ed25519, raw 32 bytes, base64). Safe to ship. The matching
# private key lives only in the vendor/ folder and must never be distributed.
# ---------------------------------------------------------------------------
VENDOR_PUBLIC_KEY_B64 = "X7YL8Mf7W1fV7zjTho2emzbcN42WDM7Jlyhu02IL3+U="

PREFIX = "IEC101-1."
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LICENSE_PATH = os.environ.get("IEC101_LICENSE",
                              os.path.join(BASE, "license.key"))


# ---------------------------------------------------------------------------
# base64url helpers (no padding, URL-safe) for compact one-line tokens
# ---------------------------------------------------------------------------
def _b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def _b64d(s: str) -> bytes:
    s = s.strip()
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def canonical(payload: dict) -> bytes:
    """Deterministic JSON serialization used for signing & verifying."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


# ---------------------------------------------------------------------------
# machine fingerprint (node-lock)
# ---------------------------------------------------------------------------
def machine_id() -> str:
    """A stable, human-readable machine identifier for node-locked licenses."""
    raw = f"{uuid.getnode():012x}|{platform.node()}|{platform.machine()}"
    h = hashlib.sha256(raw.encode()).hexdigest().upper()
    return f"{h[0:4]}-{h[4:8]}-{h[8:12]}"


# ---------------------------------------------------------------------------
# verification
# ---------------------------------------------------------------------------
class LicenseError(Exception):
    pass


def _public_key():
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    return Ed25519PublicKey.from_public_bytes(base64.b64decode(VENDOR_PUBLIC_KEY_B64))


def parse_and_verify(token: str) -> dict:
    """
    Verify a license token's signature and return its payload dict.
    Raises LicenseError on any structural or cryptographic problem.
    """
    from cryptography.exceptions import InvalidSignature
    token = (token or "").strip()
    # tolerate pasted multi-line "license file" with header lines
    for line in token.splitlines():
        line = line.strip()
        if line.startswith(PREFIX):
            token = line
            break
    if not token.startswith(PREFIX):
        raise LicenseError("Not a valid license token.")
    body = token[len(PREFIX):]
    try:
        payload_b64, sig_b64 = body.split(".")
        payload_bytes = _b64d(payload_b64)
        signature = _b64d(sig_b64)
        payload = json.loads(payload_bytes)
    except Exception:
        raise LicenseError("License token is malformed.")
    # signature must cover the exact canonical form of the payload
    try:
        _public_key().verify(signature, canonical(payload))
    except InvalidSignature:
        raise LicenseError("License signature is invalid (tampered or fake).")
    except Exception as exc:                       # noqa: BLE001
        raise LicenseError(f"Signature check failed: {exc}")
    return payload


def _days_left(expires: str):
    if not expires or expires == "never":
        return None
    try:
        exp = datetime.date.fromisoformat(expires)
    except ValueError:
        raise LicenseError("License expiry date is invalid.")
    return (exp - datetime.date.today()).days


def evaluate(token: str) -> dict:
    """
    Full evaluation: signature + expiry + machine lock. Returns a status dict
    describing the license and whether it currently grants access.
    """
    payload = parse_and_verify(token)
    status = {
        "valid": False,
        "reason": "",
        "licensee": payload.get("name", ""),
        "org": payload.get("org", ""),
        "email": payload.get("email", ""),
        "type": payload.get("type", "standard"),
        "issued": payload.get("issued", ""),
        "expires": payload.get("expires", ""),
        "lid": payload.get("lid", ""),
        "seats": payload.get("seats", 1),
        "machine": payload.get("machine", ""),
        "note": payload.get("note", ""),
        "days_left": None,
    }
    # expiry
    days = _days_left(payload.get("expires", "never"))
    status["days_left"] = days
    if days is not None and days < 0:
        status["reason"] = f"License expired on {payload.get('expires')}."
        return status
    # machine lock
    lock = payload.get("machine", "")
    if lock and lock != machine_id():
        status["reason"] = ("License is locked to another machine "
                            f"(this machine: {machine_id()}).")
        return status
    status["valid"] = True
    status["reason"] = "Licensed."
    return status


# ---------------------------------------------------------------------------
# persistence
# ---------------------------------------------------------------------------
def load_saved():
    try:
        with open(LICENSE_PATH, "r", encoding="utf-8") as fh:
            return fh.read()
    except Exception:
        return ""


def save(token: str):
    with open(LICENSE_PATH, "w", encoding="utf-8") as fh:
        fh.write(token.strip() + "\n")


def current_status() -> dict:
    """Evaluate the currently installed license (if any)."""
    token = load_saved()
    if not token:
        return {"valid": False, "reason": "No license installed.",
                "machine": machine_id(), "installed": False}
    try:
        st = evaluate(token)
    except LicenseError as exc:
        return {"valid": False, "reason": str(exc),
                "machine": machine_id(), "installed": True}
    st["installed"] = True
    st["this_machine"] = machine_id()
    return st
