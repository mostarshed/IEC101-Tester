# -*- coding: utf-8 -*-
"""
Runtime session: owns the transport, the link master, (optionally) the built-in
slave simulator, the live point database, the rolling trace buffer and the
logger. The web layer talks only to this object.
"""

import threading
import collections
import logging
import logging.handlers
import os
import time
import datetime

from iec101 import (LinkMaster, SlaveSimulator, VirtualPair, SerialTransport,
                    default_database, commands)
from iec101.asdu import Sizes
from iec101.constants import (TypeID, TYPE_NAMES, qds_to_text, DPI_NAMES,
                              COT_NAMES)

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "logs")
os.makedirs(LOG_DIR, exist_ok=True)


def _make_logger():
    log = logging.getLogger("iec101")
    log.setLevel(logging.DEBUG)
    if not log.handlers:
        fmt = logging.Formatter(
            "%(asctime)s.%(msecs)03d | %(levelname)-5s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S")
        fh = logging.handlers.RotatingFileHandler(
            os.path.join(LOG_DIR, "iec101.log"), maxBytes=2_000_000,
            backupCount=5, encoding="utf-8")
        fh.setFormatter(fmt)
        log.addHandler(fh)
        ch = logging.StreamHandler()
        ch.setFormatter(fmt)
        log.addHandler(ch)
    return log


class PointRecord:
    __slots__ = ("ioa", "type_id", "value", "quality", "time", "cot",
                 "updated", "count", "name",
                 "expected_type", "unit", "group", "desc")

    def __init__(self, ioa):
        self.ioa = ioa
        self.type_id = None
        self.value = None
        self.quality = 0
        self.time = None
        self.cot = None
        self.updated = None
        self.count = 0
        self.name = ""
        # pre-configuration fields (from the project point database)
        self.expected_type = None    # type_id the engineer defined for this IOA
        self.unit = ""
        self.group = 1
        self.desc = ""

    @property
    def received(self):
        return self.count > 0

    @property
    def type_mismatch(self):
        return (self.expected_type is not None and self.type_id is not None
                and self.expected_type != self.type_id)

    def to_dict(self):
        return {
            "ioa": self.ioa,
            "type_id": self.type_id,
            "type_name": TYPE_NAMES.get(self.type_id, ""),
            "expected_type": self.expected_type,
            "expected_type_name": TYPE_NAMES.get(self.expected_type, "") if self.expected_type else "",
            "type_mismatch": self.type_mismatch,
            "received": self.received,
            "value": self.value,
            "display": self._display(),
            "quality": self.quality,
            "quality_text": qds_to_text(self.quality),
            "time": self.time,
            "cot": self.cot,
            "cot_name": COT_NAMES.get(self.cot, str(self.cot)) if self.cot else "",
            "updated": self.updated,
            "count": self.count,
            "name": self.name,
            "unit": self.unit,
            "group": self.group,
            "desc": self.desc,
        }

    def _display(self):
        if self.value is None:
            return "—"
        tid = self.type_id or self.expected_type
        if tid in (TypeID.M_DP_NA_1, TypeID.M_DP_TB_1):
            return DPI_NAMES.get(self.value, str(self.value))
        if tid in (TypeID.M_SP_NA_1, TypeID.M_SP_TB_1):
            return "ON" if self.value else "OFF"
        if isinstance(self.value, float):
            s = f"{self.value:.3f}"
            return f"{s} {self.unit}".strip() if self.unit else s
        return str(self.value)


class Session:
    def __init__(self):
        self.log = _make_logger()
        self.cfg = self._default_cfg()
        self.master = None
        self.slave = None
        self.transport = None
        self.sim_transport = None
        self.running = False
        self.mode = "simulator"              # 'simulator' | 'serial'
        self.points = {}                     # ioa -> PointRecord
        self.trace = collections.deque(maxlen=5000)
        self._subscribers = set()            # set of callables(dict)
        self._lock = threading.Lock()
        self.point_names = {}                # optional ioa -> label from UI
        self.point_db = {}                   # ioa -> definition (pre-config)
        self.project_meta = {}               # engineer, project, AOC, SCC, station…
        self.started_at = None

    @staticmethod
    def _default_cfg():
        return {
            "mode": "simulator",
            "port": "COM1",
            "baudrate": 9600,
            "parity": "E",
            "bytesize": 8,
            "stopbits": 1,
            "link_address": 1,
            "link_addr_len": 2,
            "common_address": 1,
            "cot_len": 2,
            "common_len": 2,
            "ioa_len": 3,
            "balanced": False,
            "poll_interval": 1.0,
            "response_timeout": 1.0,
        }

    # -- subscription for WebSocket streaming ------------------------------
    def subscribe(self, fn):
        with self._lock:
            self._subscribers.add(fn)

    def unsubscribe(self, fn):
        with self._lock:
            self._subscribers.discard(fn)

    def _broadcast(self, msg):
        for fn in list(self._subscribers):
            try:
                fn(msg)
            except Exception:
                pass

    # -- event handling from the stack -------------------------------------
    def _on_event(self, event):
        d = event.to_dict()
        # feed the trace ring + log file
        self.trace.append(d)
        lvl = d.get("level", "info")
        text = d.get("text", "")
        if d["kind"] == "frame":
            arrow = "TX ->" if d["direction"] == "tx" else "RX <-"
            hexs = d.get("hex", "")
            fr = d.get("frame", {})
            fn = fr.get("function")
            summary = f"{arrow} [{fr.get('kind','')}] fn={fn} addr={fr.get('address')} {hexs}"
            if d.get("asdu"):
                a = d["asdu"]
                summary += f" | ASDU {a['type_name']} COT={a['cot_name']} CA={a['common_address']} obj={len(a['objects'])}"
            self.log.debug(summary)
            if d.get("asdu"):
                self._apply_asdu(d["asdu"])
        elif d["kind"] == "asdu":
            self.log.info(text)
        elif d["kind"] == "raw":
            self.log.log(5, f"raw {d['direction']} {d.get('hex','')}")
        elif d["kind"] == "state":
            self.log.warning(f"LINK STATE: {text}")
        else:
            getattr(self.log, lvl if lvl in ("debug", "info", "warning", "error")
                    else "info", self.log.info)(text)
        self._broadcast({"type": "trace", "data": d})

    def _apply_asdu(self, a):
        """Update the live point database from a received monitor ASDU."""
        tid = a["type_id"]
        if tid >= 45 and tid < 70:       # control-direction mirror, skip DB
            if a["cot_name"] not in ("ret-remote", "ret-local"):
                return
        for obj in a["objects"]:
            ioa = obj["ioa"]
            if ioa == 0 and tid >= 70:
                continue
            rec = self.points.get(ioa)
            if rec is None:
                rec = PointRecord(ioa)
                self.points[ioa] = rec
                self._apply_definition(rec)
            rec.type_id = tid
            rec.value = obj["value"]
            rec.quality = obj.get("quality", 0)
            rec.time = obj.get("time")
            rec.cot = a["cot"]
            rec.updated = datetime.datetime.now().isoformat(timespec="milliseconds")
            rec.count += 1
            if ioa in self.point_names:
                rec.name = self.point_names[ioa]
            if rec.type_mismatch:
                self.log.warning(
                    f"IOA {ioa}: type mismatch — expected "
                    f"{TYPE_NAMES.get(rec.expected_type)} but received "
                    f"{TYPE_NAMES.get(tid)}")
        self._broadcast({"type": "points",
                         "data": [self.points[o["ioa"]].to_dict()
                                  for o in a["objects"] if o["ioa"] in self.points]})

    # -- lifecycle ----------------------------------------------------------
    def configure(self, cfg):
        self.cfg.update(cfg)
        return self.cfg

    def start(self):
        if self.running:
            self.stop()
        self.mode = self.cfg.get("mode", "simulator")
        self.points.clear()
        self.log.info(f"=== Starting session in {self.mode} mode ===")

        if self.mode == "simulator":
            pair = VirtualPair(latency=0.002)
            self.transport = pair.master
            self.sim_transport = pair.slave
            self.slave = SlaveSimulator(self.sim_transport, self.cfg,
                                        on_event=self._on_event)
            self.slave.start()
        else:
            self.transport = SerialTransport(
                port=self.cfg["port"], baudrate=self.cfg["baudrate"],
                parity=self.cfg["parity"], bytesize=self.cfg["bytesize"],
                stopbits=self.cfg["stopbits"])
            self.slave = None

        self.master = LinkMaster(self.transport, self.cfg,
                                 on_event=self._on_event)
        self.master.start()
        self.running = True
        self.started_at = datetime.datetime.now().isoformat(timespec="seconds")
        self._broadcast({"type": "status", "data": self.status()})

    def stop(self):
        if self.master:
            self.master.stop()
        if self.slave:
            self.slave.stop()
        if self.transport:
            self.transport.close()
        self.running = False
        self.log.info("=== Session stopped ===")
        self._broadcast({"type": "status", "data": self.status()})

    # -- command dispatch ---------------------------------------------------
    def send_command(self, kind, params):
        if not (self.running and self.master):
            raise RuntimeError("session not running")
        builder = commands.BUILDERS.get(kind)
        if builder is None:
            raise ValueError(f"unknown command '{kind}'")
        common = params.pop("common", self.cfg["common_address"])
        asdu = builder(common, self.master.sizes, **params)
        self.master.send_asdu(asdu)
        self.log.info(f"COMMAND queued: {kind} {params}")
        return {"queued": kind, "params": params,
                "type_name": asdu.type_name}

    # -- introspection ------------------------------------------------------
    def status(self):
        return {
            "running": self.running,
            "mode": self.mode,
            "link_up": bool(self.master and self.master.link_up),
            "stats": self.master.stats if self.master else {},
            "started_at": self.started_at,
            "points": len(self.points),
            "config": self.cfg,
        }

    def snapshot_points(self):
        """Merge configured (defined) points with live records so pre-addressed
        points show up even before any telegram has arrived."""
        merged = {}
        # 1) start from the defined point database (desk configuration)
        for ioa, d in self.point_db.items():
            rec = self.points.get(ioa)
            if rec is None:
                rec = PointRecord(ioa)
                self._apply_definition(rec)
            merged[ioa] = rec
        # 2) add anything received live that wasn't pre-defined
        for ioa, rec in self.points.items():
            merged[ioa] = rec
        return [r.to_dict() for r in sorted(merged.values(), key=lambda r: r.ioa)]

    def _apply_definition(self, rec: "PointRecord"):
        d = self.point_db.get(rec.ioa)
        if not d:
            return
        rec.expected_type = d.get("type_id")
        rec.name = d.get("name", rec.name)
        rec.unit = d.get("unit", "")
        rec.group = d.get("group", 1)
        rec.desc = d.get("desc", "")

    def set_names(self, names: dict):
        self.point_names.update({int(k): v for k, v in names.items()})
        for ioa, label in self.point_names.items():
            if ioa in self.points:
                self.points[ioa].name = label

    # -- project configuration ---------------------------------------------
    def set_point_db(self, points: list):
        """Install the pre-configured point database (list of definitions)."""
        db = {}
        for p in points:
            try:
                ioa = int(p["ioa"])
            except (KeyError, ValueError, TypeError):
                continue
            db[ioa] = {
                "ioa": ioa,
                "name": p.get("name", ""),
                "type_id": int(p.get("type_id")) if p.get("type_id") else None,
                "unit": p.get("unit", ""),
                "group": int(p.get("group", 1) or 1),
                "desc": p.get("desc", ""),
            }
        self.point_db = db
        # refresh any live records with the new definitions + names
        self.point_names = {ioa: d["name"] for ioa, d in db.items() if d["name"]}
        for ioa, rec in self.points.items():
            self._apply_definition(rec)
        self.log.info(f"Point database set: {len(db)} points defined.")
        return db

    def get_point_db(self):
        return [self.point_db[k] for k in sorted(self.point_db)]

    def set_project_meta(self, meta: dict):
        self.project_meta.update(meta or {})
        return self.project_meta

    def new_project(self):
        """Clear everything for a fresh project."""
        self.point_db = {}
        self.point_names = {}
        self.project_meta = {}
        self.points.clear()
        self.log.info("New project created (configuration cleared).")

    def clear_trace(self):
        self.trace.clear()

    def recent_trace(self, limit=500):
        return list(self.trace)[-limit:]
