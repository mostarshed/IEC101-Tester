# -*- coding: utf-8 -*-
"""
Web server for the IEC 60870-5-101 tester.

FastAPI + uvicorn. Serves the single-page frontend from ./static, exposes a
small REST API for configuration / commands / point database, and a WebSocket
that streams the live packet trace and point updates to the browser.
"""

import os
import json
import asyncio
import queue
import threading
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from session import Session
import licensing
from iec101 import list_serial_ports
from iec101.constants import TYPE_NAMES, TYPE_DESC, COT_NAMES

BASE = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(BASE, "static")


@asynccontextmanager
async def lifespan(app: FastAPI):
    loop = asyncio.get_event_loop()
    task = loop.create_task(_pump())
    yield
    task.cancel()


app = FastAPI(title="IEC 60870-5-101 Tester", lifespan=lifespan)
SESSION = Session()

# a thread-safe bridge: stack events (any thread) -> asyncio websocket clients
_WS_CLIENTS = set()
_EVENT_Q: "queue.Queue" = queue.Queue(maxsize=20000)


def _push(msg):
    try:
        _EVENT_Q.put_nowait(msg)
    except queue.Full:
        pass


SESSION.subscribe(_push)


async def _pump():
    """Drain the thread queue and fan out to connected websockets."""
    while True:
        try:
            msg = await asyncio.get_event_loop().run_in_executor(
                None, _EVENT_Q.get)
        except Exception:
            await asyncio.sleep(0.05)
            continue
        dead = []
        payload = json.dumps(msg, default=str)
        for ws in list(_WS_CLIENTS):
            try:
                await ws.send_text(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            _WS_CLIENTS.discard(ws)


# ---------------------------------------------------------------------------
# Licensing gate
# ---------------------------------------------------------------------------
def _require_license():
    st = licensing.current_status()
    if not st.get("valid"):
        raise HTTPException(status_code=403,
                            detail=st.get("reason", "No valid license."))


@app.get("/api/license/status")
async def license_status():
    return licensing.current_status()


@app.post("/api/license/activate")
async def license_activate(req: Request):
    body = await req.json()
    token = body.get("token", "")
    try:
        st = licensing.evaluate(token)
    except licensing.LicenseError as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)
    if not st["valid"]:
        return JSONResponse({"ok": False, "error": st["reason"]}, status_code=400)
    licensing.save(token)
    st = licensing.current_status()
    return {"ok": True, "status": st}


# ---------------------------------------------------------------------------
# REST API
# ---------------------------------------------------------------------------
@app.get("/api/status")
async def status():
    return SESSION.status()


@app.get("/api/ports")
async def ports():
    return {"ports": list_serial_ports()}


@app.get("/api/types")
async def types():
    return {"types": [{"id": k, "name": v, "desc": TYPE_DESC.get(k, "")}
                      for k, v in sorted(TYPE_NAMES.items())],
            "cot": [{"id": k, "name": v} for k, v in sorted(COT_NAMES.items())]}


@app.post("/api/config")
async def config(req: Request):
    body = await req.json()
    return {"config": SESSION.configure(body)}


@app.post("/api/start")
async def start():
    _require_license()
    try:
        SESSION.start()
        return {"ok": True, "status": SESSION.status()}
    except Exception as exc:                       # noqa: BLE001
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)


@app.post("/api/stop")
async def stop():
    SESSION.stop()
    return {"ok": True, "status": SESSION.status()}


@app.get("/api/points")
async def points():
    return {"points": SESSION.snapshot_points()}


@app.post("/api/points/names")
async def point_names(req: Request):
    body = await req.json()
    SESSION.set_names(body.get("names", {}))
    return {"ok": True}


@app.post("/api/command")
async def command(req: Request):
    _require_license()
    body = await req.json()
    kind = body.get("kind")
    params = body.get("params", {})
    try:
        result = SESSION.send_command(kind, params)
        return {"ok": True, "result": result}
    except Exception as exc:                        # noqa: BLE001
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)


@app.get("/api/trace")
async def trace(limit: int = 500):
    return {"trace": SESSION.recent_trace(limit)}


@app.post("/api/trace/clear")
async def trace_clear():
    SESSION.clear_trace()
    return {"ok": True}


# -- SLD persistence (stored on disk next to the app) -----------------------
SLD_FILE = os.path.join(BASE, "..", "sld_diagrams.json")


def _load_sld():
    try:
        with open(SLD_FILE, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {"diagrams": {}}


def _save_sld(data):
    with open(SLD_FILE, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)


@app.get("/api/sld")
async def sld_load():
    return _load_sld()


@app.post("/api/sld")
async def sld_save(req: Request):
    body = await req.json()
    _save_sld(body)
    return {"ok": True}


# -- Project export / import (config + point names + SLD) -------------------
import datetime as _dt


@app.get("/api/project")
async def project_export():
    """Bundle the whole working project for download."""
    return {
        "format": "iec101-project",
        "version": 2,
        "exported_at": _dt.datetime.now().isoformat(timespec="seconds"),
        "meta": SESSION.project_meta,
        "config": SESSION.cfg,
        "point_db": SESSION.get_point_db(),
        "point_names": SESSION.point_names,
        "points": SESSION.snapshot_points(),
        "sld": _load_sld(),
    }


@app.post("/api/project")
async def project_import(req: Request):
    """Restore a project bundle: meta, config, point database and SLD."""
    body = await req.json()
    if body.get("format") != "iec101-project":
        return JSONResponse({"ok": False, "error": "Not an IEC101 project file."},
                            status_code=400)
    applied = []
    if isinstance(body.get("meta"), dict):
        SESSION.set_project_meta(body["meta"]); applied.append("meta")
    if isinstance(body.get("config"), dict):
        SESSION.configure(body["config"]); applied.append("config")
    if isinstance(body.get("point_db"), list):
        SESSION.set_point_db(body["point_db"]); applied.append("point_db")
    elif isinstance(body.get("point_names"), dict):
        SESSION.set_names(body["point_names"]); applied.append("point_names")
    if isinstance(body.get("sld"), dict):
        _save_sld(body["sld"]); applied.append("sld")
    return {"ok": True, "applied": applied, "config": SESSION.cfg,
            "meta": SESSION.project_meta, "point_db": SESSION.get_point_db()}


# -- project configuration endpoints ----------------------------------------
@app.get("/api/pointdb")
async def pointdb_get():
    return {"points": SESSION.get_point_db()}


@app.post("/api/pointdb")
async def pointdb_set(req: Request):
    body = await req.json()
    db = SESSION.set_point_db(body.get("points", []))
    return {"ok": True, "count": len(db)}


@app.get("/api/meta")
async def meta_get():
    return {"meta": SESSION.project_meta}


@app.post("/api/meta")
async def meta_set(req: Request):
    body = await req.json()
    return {"ok": True, "meta": SESSION.set_project_meta(body.get("meta", {}))}


@app.post("/api/project/new")
async def project_new():
    SESSION.new_project()
    _save_sld({"diagrams": {}})
    return {"ok": True}


# -- report generation (DOC + PDF) ------------------------------------------
@app.get("/api/report")
async def report(format: str = "pdf"):
    import report as report_mod
    data = {
        "meta": SESSION.project_meta,
        "config": SESSION.cfg,
        "points": SESSION.snapshot_points(),
        "status": SESSION.status(),
    }
    try:
        if format == "docx":
            path, fname = report_mod.build_docx(data)
            media = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        else:
            path, fname = report_mod.build_pdf(data)
            media = "application/pdf"
    except Exception as exc:                        # noqa: BLE001
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)
    return FileResponse(path, media_type=media, filename=fname)


# ---------------------------------------------------------------------------
# WebSocket live stream
# ---------------------------------------------------------------------------
@app.websocket("/ws")
async def ws(websocket: WebSocket):
    await websocket.accept()
    _WS_CLIENTS.add(websocket)
    # send an initial snapshot
    await websocket.send_text(json.dumps({"type": "status",
                                          "data": SESSION.status()}, default=str))
    await websocket.send_text(json.dumps({"type": "points_full",
                                          "data": SESSION.snapshot_points()},
                                         default=str))
    try:
        while True:
            await websocket.receive_text()   # keepalive / client pings
    except WebSocketDisconnect:
        pass
    finally:
        _WS_CLIENTS.discard(websocket)


# ---------------------------------------------------------------------------
# Frontend
# ---------------------------------------------------------------------------
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/", response_class=HTMLResponse)
async def index():
    with open(os.path.join(STATIC, "index.html"), "r", encoding="utf-8") as fh:
        return fh.read()


def _port_is_free(host, port):
    """Return True if we can actually bind the port on this machine."""
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def _choose_port(host, preferred):
    """
    Pick a usable port. Windows can forbid a port (WinError 10013) when it
    falls inside a reserved/excluded range (Hyper-V, WSL, Docker). We try the
    preferred port, then a list of common fallbacks, then let the OS assign a
    free one so the app always starts.
    """
    candidates = [preferred, 8101, 8201, 8808, 8900, 9101, 9900, 5101, 18101]
    seen = set()
    for p in candidates:
        if p in seen:
            continue
        seen.add(p)
        if _port_is_free(host, p):
            return p
    # last resort: ask the OS for any free port
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, 0))
    p = s.getsockname()[1]
    s.close()
    return p


def _open_browser(url, delay=2.0):
    import threading, webbrowser, time

    def _go():
        time.sleep(delay)
        try:
            webbrowser.open(url)
        except Exception:
            pass
    threading.Thread(target=_go, daemon=True).start()


def main():
    import uvicorn
    host = os.environ.get("IEC101_HOST", "127.0.0.1")
    preferred = int(os.environ.get("IEC101_PORT", "8101"))
    port = _choose_port(host, preferred)

    url = f"http://{host}:{port}"
    print("\n  " + "=" * 52)
    print(f"   IEC 60870-5-101 Tester is running at:  {url}")
    if port != preferred:
        print(f"   (port {preferred} was blocked by Windows, using {port} instead)")
    print("   Keep this window open. Press Ctrl+C to stop.")
    print("  " + "=" * 52 + "\n")

    _open_browser(url)
    uvicorn.run(app, host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
