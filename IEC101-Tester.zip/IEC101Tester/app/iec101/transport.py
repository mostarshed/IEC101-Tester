# -*- coding: utf-8 -*-
"""
Transports for the IEC 101 link layer.

Two implementations share a tiny interface (``write``, ``read``, ``close``):

  * SerialTransport  - a real RS-232 / RS-485 port via pyserial.
  * VirtualPair      - an in-memory pipe used to wire the master to the
                        built-in slave simulator so the whole application
                        works end-to-end with no hardware attached.

``list_serial_ports`` is a thin wrapper around pyserial's enumerator used by
the web UI to populate the COM-port dropdown.
"""

import threading
import collections
import time


def list_serial_ports():
    try:
        from serial.tools import list_ports
    except Exception:
        return []
    ports = []
    for p in list_ports.comports():
        ports.append({"device": p.device,
                      "description": p.description or "",
                      "hwid": p.hwid or ""})
    return ports


class SerialTransport:
    """Real serial port transport."""

    def __init__(self, port, baudrate=9600, bytesize=8, parity="E",
                 stopbits=1, timeout=0.05):
        import serial
        parity_map = {"N": serial.PARITY_NONE, "E": serial.PARITY_EVEN,
                      "O": serial.PARITY_ODD, "M": serial.PARITY_MARK,
                      "S": serial.PARITY_SPACE}
        stop_map = {1: serial.STOPBITS_ONE, 1.5: serial.STOPBITS_ONE_POINT_FIVE,
                    2: serial.STOPBITS_TWO}
        self.ser = serial.Serial(
            port=port, baudrate=baudrate, bytesize=bytesize,
            parity=parity_map.get(parity.upper(), serial.PARITY_EVEN),
            stopbits=stop_map.get(stopbits, serial.STOPBITS_ONE),
            timeout=timeout)
        self.port = port

    def write(self, data: bytes):
        self.ser.write(data)
        self.ser.flush()

    def read(self, size=256, timeout=None):
        if timeout is not None:
            self.ser.timeout = timeout
        return self.ser.read(size)

    def close(self):
        try:
            self.ser.close()
        except Exception:
            pass


class _Pipe:
    """One-directional thread-safe byte pipe."""

    def __init__(self):
        self._buf = collections.deque()
        self._cv = threading.Condition()

    def put(self, data: bytes):
        with self._cv:
            self._buf.extend(data)
            self._cv.notify_all()

    def get(self, size=256, timeout=0.05):
        with self._cv:
            if not self._buf:
                self._cv.wait(timeout=timeout)
            out = bytearray()
            while self._buf and len(out) < size:
                out.append(self._buf.popleft())
            return bytes(out)


class VirtualEndpoint:
    """One side of a VirtualPair, exposing the transport interface."""

    def __init__(self, rx: _Pipe, tx: _Pipe, latency=0.0):
        self._rx = rx
        self._tx = tx
        self.latency = latency

    def write(self, data: bytes):
        if self.latency:
            time.sleep(self.latency)
        self._tx.put(data)

    def read(self, size=256, timeout=0.05):
        return self._rx.get(size, timeout=timeout)

    def close(self):
        pass


class VirtualPair:
    """Creates two cross-connected endpoints (master side / slave side)."""

    def __init__(self, latency=0.0):
        a2b = _Pipe()
        b2a = _Pipe()
        self.master = VirtualEndpoint(rx=b2a, tx=a2b, latency=latency)
        self.slave = VirtualEndpoint(rx=a2b, tx=b2a, latency=latency)
