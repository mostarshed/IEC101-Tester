# -*- coding: utf-8 -*-
"""
CP56Time2a and CP24Time2a time tag encode / decode (IEC 60870-5-4).

CP56Time2a is 7 octets:
    [0..1] milliseconds (0..59999, little endian)
    [2]    minutes (bits0..5), IV flag (bit7)
    [3]    hours   (bits0..4), SU summer-time flag (bit7)
    [4]    day of month (bits0..4), day of week (bits5..7)
    [5]    month (bits0..3)
    [6]    year (bits0..6, 0..99 -> 2000..2099)
"""

import datetime


def encode_cp56(dt: datetime.datetime | None) -> bytes:
    if dt is None:
        dt = datetime.datetime.now()
    ms = dt.second * 1000 + dt.microsecond // 1000
    dow = dt.isoweekday()  # 1 = Monday .. 7 = Sunday
    return bytes([
        ms & 0xFF,
        (ms >> 8) & 0xFF,
        dt.minute & 0x3F,
        dt.hour & 0x1F,
        (dt.day & 0x1F) | ((dow & 0x07) << 5),
        dt.month & 0x0F,
        (dt.year - 2000) & 0x7F,
    ])


def decode_cp56(raw: bytes) -> datetime.datetime:
    if len(raw) < 7:
        raise ValueError("CP56Time2a needs 7 octets")
    ms = raw[0] | (raw[1] << 8)
    second = ms // 1000
    micro = (ms % 1000) * 1000
    minute = raw[2] & 0x3F
    hour = raw[3] & 0x1F
    day = raw[4] & 0x1F
    month = raw[5] & 0x0F
    year = 2000 + (raw[6] & 0x7F)
    try:
        return datetime.datetime(year, max(1, month), max(1, day),
                                 hour, minute, second, micro)
    except ValueError:
        # tolerate out-of-range values coming from a misbehaving slave
        return datetime.datetime.now()


def encode_cp24(dt: datetime.datetime | None) -> bytes:
    if dt is None:
        dt = datetime.datetime.now()
    ms = dt.second * 1000 + dt.microsecond // 1000
    return bytes([ms & 0xFF, (ms >> 8) & 0xFF, dt.minute & 0x3F])


def decode_cp24(raw: bytes, ref: datetime.datetime | None = None) -> datetime.datetime:
    ref = ref or datetime.datetime.now()
    ms = raw[0] | (raw[1] << 8)
    return ref.replace(minute=raw[2] & 0x3F, second=ms // 1000,
                       microsecond=(ms % 1000) * 1000)
