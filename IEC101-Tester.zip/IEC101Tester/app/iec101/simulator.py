# -*- coding: utf-8 -*-
"""
Built-in substation-gateway simulator (IEC 101 outstation / slave).

The simulator makes the tester useful out of the box: pick the "Simulator"
transport in the UI and a virtual power-substation gateway answers on the
other end of a VirtualPair. It models a small bay:

  * single / double point status (breakers, disconnectors)
  * step position (tap changer)
  * measured values (V, I, P, Q, f) that drift realistically
  * counters
  * responds to General Interrogation, Counter Interrogation, Clock Sync,
    single / double commands (with ACT-CON / ACT-TERM and return information)

It runs its own thread, speaks the unbalanced secondary link procedure, keeps
class-1 (events) and class-2 (cyclic) queues, and raises spontaneous events on
command execution so the tester's monitor view lights up.
"""

import threading
import time
import random
import datetime

from .frame import Frame, FrameDecoder
from .asdu import ASDU, InfoObject, encode_asdu, decode_asdu, Sizes
from .constants import (
    CF_PRM, CF_FCB, CF_FCV, CF_ACD, CF_DFC, SINGLE_CHAR_E5,
    PrimaryFunction, SecondaryFunction, TypeID, COT, DPI,
)


class SimPoint:
    def __init__(self, ioa, type_id, value, name="", group=1):
        self.ioa = ioa
        self.type_id = type_id
        self.value = value
        self.quality = 0
        self.name = name
        self.group = group          # interrogation group (1..16)
        self.time = None


def default_database():
    """A representative bay of a transmission substation gateway."""
    pts = [
        SimPoint(1001, TypeID.M_DP_NA_1, DPI.ON,  "CB-Q0 Breaker 230kV"),
        SimPoint(1002, TypeID.M_DP_NA_1, DPI.OFF, "DS-Q1 Disconnector bus-1"),
        SimPoint(1003, TypeID.M_DP_NA_1, DPI.OFF, "DS-Q2 Disconnector bus-2"),
        SimPoint(1004, TypeID.M_DP_NA_1, DPI.ON,  "ES-Q8 Earth switch"),
        SimPoint(1005, TypeID.M_SP_NA_1, 0,       "Protection trip (86)"),
        SimPoint(1006, TypeID.M_SP_NA_1, 1,       "Local/Remote selector"),
        SimPoint(1007, TypeID.M_SP_NA_1, 0,       "SF6 low pressure alarm"),
        SimPoint(1008, TypeID.M_ST_NA_1, 8,       "Transformer tap position"),
        SimPoint(2001, TypeID.M_ME_NC_1, 231.4,   "Voltage L1 (kV)"),
        SimPoint(2002, TypeID.M_ME_NC_1, 230.9,   "Voltage L2 (kV)"),
        SimPoint(2003, TypeID.M_ME_NC_1, 231.1,   "Voltage L3 (kV)"),
        SimPoint(2004, TypeID.M_ME_NC_1, 412.0,   "Current L1 (A)"),
        SimPoint(2005, TypeID.M_ME_NC_1, 408.5,   "Current L2 (A)"),
        SimPoint(2006, TypeID.M_ME_NC_1, 410.2,   "Current L3 (A)"),
        SimPoint(2007, TypeID.M_ME_NC_1, 164.3,   "Active power P (MW)"),
        SimPoint(2008, TypeID.M_ME_NC_1, 48.7,    "Reactive power Q (MVAr)"),
        SimPoint(2009, TypeID.M_ME_NC_1, 50.01,   "Frequency (Hz)"),
        SimPoint(2010, TypeID.M_ME_NB_1, 8750,    "Transformer temp (0.1°C)"),
        SimPoint(3001, TypeID.M_IT_NA_1, 1234567, "Energy import (kWh)"),
        SimPoint(3002, TypeID.M_IT_NA_1, 98765,   "Energy export (kWh)"),
    ]
    return {p.ioa: p for p in pts}


class SlaveSimulator:
    def __init__(self, transport, config, on_event=None, point_db=None):
        self.transport = transport
        self.cfg = config
        self.on_event = on_event or (lambda e: None)
        self.sizes = Sizes(cot_len=config.get("cot_len", 2),
                           common_len=config.get("common_len", 2),
                           ioa_len=config.get("ioa_len", 3))
        self.link_addr = config.get("link_address", 1)
        self.addr_len = config.get("link_addr_len", 2)
        self.common_addr = config.get("common_address", 1)
        self.points = point_db or default_database()

        self._decoder = FrameDecoder(addr_len=self.addr_len)
        self._class1 = []     # event queue (spontaneous, returns)
        self._class2 = []     # cyclic queue
        self._fcb_expected = False
        self._running = False
        self._thread = None
        self._cyc_thread = None
        self._lock = threading.Lock()

    # -- lifecycle ----------------------------------------------------------
    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True,
                                        name="iec101-slave")
        self._thread.start()
        self._cyc_thread = threading.Thread(target=self._cyclic, daemon=True,
                                            name="iec101-slave-cyc")
        self._cyc_thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)

    def _log(self, text, level="debug"):
        from .link import LinkEvent
        self.on_event(LinkEvent("log", text="[SIM] " + text, level=level))

    # -- ASDU construction helpers -----------------------------------------
    def _point_object(self, p: SimPoint):
        return InfoObject(ioa=p.ioa, value=p.value, quality=p.quality,
                          time=p.time)

    def _build(self, type_id, cot, objs, negative=False):
        return ASDU(type_id=type_id, cot=cot, common_address=self.common_addr,
                    objects=objs, sizes=self.sizes, negative=negative)

    def _queue_event(self, asdu, class1=True):
        (self._class1 if class1 else self._class2).append(asdu)

    # -- link send ----------------------------------------------------------
    def _send(self, frame: Frame):
        self.transport.write(frame.encode())

    def _send_single_ack(self):
        self._send(Frame.single(SINGLE_CHAR_E5))

    def _control_secondary(self, function, acd=False, dfc=False):
        c = function & 0x0F
        if acd:
            c |= CF_ACD
        if dfc:
            c |= CF_DFC
        return c

    def _respond_user_data(self, asdu: ASDU, more_class1: bool):
        payload = encode_asdu(asdu)
        c = self._control_secondary(SecondaryFunction.RESP_USER_DATA,
                                    acd=more_class1)
        self._send(Frame.variable(c, self.link_addr, payload, self.addr_len))

    # -- main receive loop --------------------------------------------------
    def _run(self):
        self._log("Slave simulator started.")
        while self._running:
            data = self.transport.read(256, timeout=0.05)
            if not data:
                continue
            for fr in self._decoder.feed(data):
                self._handle(fr)

    def _handle(self, fr: Frame):
        if fr.kind == Frame.SINGLE:
            return
        if fr.address not in (self.link_addr, 0xFF, 0xFFFF):
            return  # not addressed to us (broadcast tolerated)

        func = fr.control & 0x0F
        prm = bool(fr.control & CF_PRM)
        if not prm:
            return

        if func == PrimaryFunction.REQ_LINK_STATUS:
            c = self._control_secondary(SecondaryFunction.STATUS_OF_LINK,
                                        acd=bool(self._class1))
            self._send(Frame.fixed(c, self.link_addr, self.addr_len))
        elif func in (PrimaryFunction.RESET_REMOTE_LINK,
                      PrimaryFunction.RESET_USER_PROCESS):
            self._fcb_expected = True
            self._class1.clear()
            self._send_single_ack()
            self._queue_eoi()
        elif func == PrimaryFunction.TEST_LINK:
            self._send_single_ack()
        elif func == PrimaryFunction.REQ_CLASS1_DATA:
            self._serve_class(class1=True)
        elif func == PrimaryFunction.REQ_CLASS2_DATA:
            self._serve_class(class1=False)
        elif func == PrimaryFunction.USER_DATA_CONFIRM:
            self._send_single_ack()        # link-layer confirm
            if fr.asdu:
                try:
                    a = decode_asdu(fr.asdu, self.sizes)
                    self._process_asdu(a)
                except Exception as exc:    # noqa: BLE001
                    self._log(f"asdu decode error: {exc}", "error")
        elif func == PrimaryFunction.USER_DATA_NO_REPLY:
            if fr.asdu:
                try:
                    self._process_asdu(decode_asdu(fr.asdu, self.sizes))
                except Exception:
                    pass

    def _serve_class(self, class1):
        q = self._class1 if class1 else self._class2
        if not class1 and not q:
            # keep cyclic data flowing: synthesise a snapshot
            self._refresh_class2()
            q = self._class2
        if q:
            asdu = q.pop(0)
            self._respond_user_data(asdu, more_class1=bool(self._class1))
        else:
            # NACK: no requested data
            c = self._control_secondary(SecondaryFunction.RESP_NACK_NO_DATA,
                                        acd=bool(self._class1))
            self._send(Frame.fixed(c, self.link_addr, self.addr_len))

    def _queue_eoi(self):
        obj = InfoObject(ioa=0, value=0)   # COI = 0 (local power on)
        self._queue_event(self._build(TypeID.M_EI_NA_1, COT.INITIALIZED, [obj]))

    # -- application processing --------------------------------------------
    def _process_asdu(self, a: ASDU):
        self._log(f"RX {a.type_name} COT={a.cot_name}")
        if a.type_id == TypeID.C_IC_NA_1:
            self._handle_interrogation(a)
        elif a.type_id == TypeID.C_CI_NA_1:
            self._handle_counter_interrogation(a)
        elif a.type_id == TypeID.C_CS_NA_1:
            self._handle_clock_sync(a)
        elif a.type_id in (TypeID.C_SC_NA_1, TypeID.C_DC_NA_1, TypeID.C_RC_NA_1,
                           TypeID.C_SE_NA_1, TypeID.C_SE_NB_1, TypeID.C_SE_NC_1):
            self._handle_command(a)
        elif a.type_id == TypeID.C_RD_NA_1:
            self._handle_read(a)
        elif a.type_id == TypeID.C_TS_NA_1:
            obj = a.objects[0] if a.objects else InfoObject(0, 0xAA55)
            self._queue_event(self._build(TypeID.C_TS_NA_1, COT.ACT_CON, [obj]))

    def _handle_interrogation(self, a: ASDU):
        qoi = a.objects[0].value if a.objects else 20
        # 1) ACT-CON mirror
        self._queue_event(self._build(TypeID.C_IC_NA_1, COT.ACT_CON,
                                      [InfoObject(0, qoi)]))
        # 2) all monitored points, grouped by type, with interrogated COT
        cot = COT.INTROGEN if qoi == 20 else (COT.INTRO_GROUP_1 + (qoi - 21))
        groups = {}
        for p in self.points.values():
            if p.type_id in (TypeID.M_IT_NA_1,):
                continue  # counters go through counter interrogation
            groups.setdefault(p.type_id, []).append(p)
        for type_id, pts in groups.items():
            objs = [self._point_object(p) for p in pts]
            self._queue_event(self._build(type_id, cot, objs))
        # 3) ACT-TERM
        self._queue_event(self._build(TypeID.C_IC_NA_1, COT.ACT_TERM,
                                      [InfoObject(0, qoi)]))
        self._log(f"General interrogation served (QOI={qoi}).", "info")

    def _handle_counter_interrogation(self, a: ASDU):
        qcc = a.objects[0].value if a.objects else 5
        self._queue_event(self._build(TypeID.C_CI_NA_1, COT.ACT_CON,
                                      [InfoObject(0, qcc)]))
        objs = [self._point_object(p) for p in self.points.values()
                if p.type_id == TypeID.M_IT_NA_1]
        if objs:
            self._queue_event(self._build(TypeID.M_IT_NA_1, COT.REQCOGEN, objs))
        self._queue_event(self._build(TypeID.C_CI_NA_1, COT.ACT_TERM,
                                      [InfoObject(0, qcc)]))

    def _handle_clock_sync(self, a: ASDU):
        obj = a.objects[0] if a.objects else InfoObject(0, "clock")
        self._queue_event(self._build(TypeID.C_CS_NA_1, COT.ACT_CON, [obj]))
        self._log("Clock synchronised.", "info")

    def _handle_read(self, a: ASDU):
        ioa = a.objects[0].ioa if a.objects else 0
        p = self.points.get(ioa)
        if p:
            self._queue_event(self._build(p.type_id, COT.REQUEST,
                                          [self._point_object(p)]))
        else:
            self._queue_event(self._build(TypeID.C_RD_NA_1, COT.UNKNOWN_OBJECT_ADDR,
                                          [InfoObject(ioa, 0)], negative=True))

    def _handle_command(self, a: ASDU):
        obj = a.objects[0]
        p = self.points.get(obj.ioa)
        select = bool(obj.quality & 0x01) if a.type_id in (
            TypeID.C_SC_NA_1, TypeID.C_DC_NA_1, TypeID.C_RC_NA_1) else False
        if p is None:
            self._queue_event(self._build(a.type_id, COT.UNKNOWN_OBJECT_ADDR,
                                          [obj], negative=True))
            return
        # confirm the activation / selection
        self._queue_event(self._build(a.type_id, COT.ACT_CON, [obj]))
        if select:
            self._log(f"SELECT on IOA {obj.ioa}", "info")
            return
        # execute: update the point and raise return information spontaneously
        if a.type_id == TypeID.C_SC_NA_1:
            p.value = 1 if obj.value else 0
        elif a.type_id == TypeID.C_DC_NA_1:
            p.value = DPI.ON if obj.value == 2 else DPI.OFF
        elif a.type_id == TypeID.C_RC_NA_1:
            step = 1 if obj.value == 2 else -1
            p.value = max(0, min(63, p.value + step))
        elif a.type_id in (TypeID.C_SE_NA_1, TypeID.C_SE_NB_1, TypeID.C_SE_NC_1):
            p.value = obj.value
        p.time = datetime.datetime.now()
        # return information (RETREM) as monitor-direction spontaneous
        ret = self._point_object(p)
        self._queue_event(self._build(p.type_id, COT.RETREM, [ret]))
        # activation termination
        self._queue_event(self._build(a.type_id, COT.ACT_TERM, [obj]))
        self._log(f"EXECUTE command on IOA {obj.ioa} -> {p.value}", "info")

    # -- cyclic + spontaneous generation -----------------------------------
    def _refresh_class2(self):
        objs = []
        for p in self.points.values():
            if p.type_id in (TypeID.M_ME_NC_1, TypeID.M_ME_NB_1):
                objs.append(self._point_object(p))
        if objs:
            # one ASDU per type id to stay standard-compliant
            by_type = {}
            for p in self.points.values():
                if p.type_id in (TypeID.M_ME_NC_1, TypeID.M_ME_NB_1):
                    by_type.setdefault(p.type_id, []).append(self._point_object(p))
            for tid, os in by_type.items():
                self._class2.append(self._build(tid, COT.PERIODIC, os))

    def _cyclic(self):
        """Drift measured values realistically and raise spontaneous events."""
        # remember nominal set-points so values mean-revert instead of wandering
        nominal = {ioa: p.value for ioa, p in self.points.items()}
        tick = 0
        while self._running:
            time.sleep(1.0)
            tick += 1
            with self._lock:
                for ioa, p in self.points.items():
                    nom = nominal.get(ioa, p.value)
                    if p.type_id == TypeID.M_ME_NC_1:
                        # tight mean-reverting walk, hard-clamped near nominal so
                        # voltage/current/frequency stay physically plausible
                        band = max(abs(nom) * 0.003, 0.01)   # ~0.3 % jitter
                        step = random.uniform(-band, band) + (nom - p.value) * 0.3
                        v = p.value + step
                        lo, hi = nom - abs(nom) * 0.02, nom + abs(nom) * 0.02
                        p.value = round(min(hi, max(lo, v)), 3)
                    elif p.type_id == TypeID.M_ME_NB_1:
                        step = random.randint(-3, 3) + int((nom - p.value) * 0.3)
                        p.value = int(p.value + step)
                    elif p.type_id == TypeID.M_IT_NA_1:
                        p.value += random.randint(0, 3)   # counters only increase
                # spontaneous status event every ~12 s
                if tick % 12 == 0:
                    p = self.points.get(1005)  # protection trip pulse
                    if p:
                        p.value = 1 - p.value
                        p.time = datetime.datetime.now()
                        self._queue_event(self._build(
                            TypeID.M_SP_TB_1, COT.SPONTANEOUS,
                            [self._point_object(p)]))
