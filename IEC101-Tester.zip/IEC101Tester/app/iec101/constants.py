# -*- coding: utf-8 -*-
"""
IEC 60870-5-101 constants, enumerations and lookup tables.

This module gathers the magic numbers of the standard in one place so the
rest of the stack can stay readable. Everything here is defined by
IEC 60870-5-101 (companion standard for basic telecontrol tasks) together
with the base standards IEC 60870-5-1/2/3/4.
"""

# ---------------------------------------------------------------------------
# FT1.2 frame control octets (IEC 60870-5-1)
# ---------------------------------------------------------------------------
START_FIXED = 0x10        # start byte of a fixed-length frame
START_VARIABLE = 0x68     # start byte of a variable-length frame
STOP = 0x16               # end byte of every frame
SINGLE_CHAR_E5 = 0xE5     # single control character (ACK, class-2 data empty)
SINGLE_CHAR_A2 = 0xA2     # alternative single control character

# ---------------------------------------------------------------------------
# Control field bit masks (the C octet of the link layer)
# ---------------------------------------------------------------------------
CF_RES = 0x80             # Reserved bit (always 0 for 101)
CF_PRM = 0x40             # Primary message bit (1 = from primary station)
CF_FCB = 0x20             # Frame Count Bit (toggles for balanced / class requests)
CF_FCV = 0x10             # Frame Count Valid bit
CF_DIR = 0x80            # In balanced mode bit7 is DIR instead of RES
CF_ACD = 0x20             # Access Demand (secondary->primary, bit5)
CF_DFC = 0x10             # Data Flow Control (secondary->primary, bit4)
CF_FUNCTION_MASK = 0x0F   # low nibble is the function code


class PrimaryFunction:
    """Function codes sent by the primary (controlling) station, PRM = 1."""
    RESET_REMOTE_LINK = 0        # reset of remote link
    RESET_USER_PROCESS = 1       # reset of user process
    TEST_LINK = 2                # test function of link
    USER_DATA_CONFIRM = 3        # user data, confirmed (ACK/NACK expected)
    USER_DATA_NO_REPLY = 4       # user data, no reply expected
    REQ_ACCESS_DEMAND = 8        # request for access demand
    REQ_LINK_STATUS = 9          # request status of link
    REQ_CLASS1_DATA = 10         # request user data class 1
    REQ_CLASS2_DATA = 11         # request user data class 2


class SecondaryFunction:
    """Function codes sent by the secondary (controlled) station, PRM = 0."""
    ACK = 0                      # positive acknowledgement (confirm)
    NACK = 1                     # negative acknowledgement
    RESP_USER_DATA = 8           # response with user data
    RESP_NACK_NO_DATA = 9        # response, no requested data available
    STATUS_OF_LINK = 11          # status of link / access demand response
    LINK_NOT_FUNCTIONING = 14    # link service not functioning
    LINK_NOT_IMPLEMENTED = 15    # link service not implemented


# ---------------------------------------------------------------------------
# ASDU Type Identification (TypeID) - IEC 60870-5-101 clause 7.2.1
# Only the set commonly exchanged with a substation gateway is enumerated.
# ---------------------------------------------------------------------------
class TypeID:
    # --- Process information in monitor direction ---
    M_SP_NA_1 = 1     # Single-point information
    M_SP_TA_1 = 2     # Single-point information with time tag (CP24Time2a)
    M_DP_NA_1 = 3     # Double-point information
    M_DP_TA_1 = 4     # Double-point information with time tag
    M_ST_NA_1 = 5     # Step position information
    M_ST_TA_1 = 6     # Step position information with time tag
    M_BO_NA_1 = 7     # Bitstring of 32 bit
    M_BO_TA_1 = 8     # Bitstring of 32 bit with time tag
    M_ME_NA_1 = 9     # Measured value, normalized
    M_ME_TA_1 = 10    # Measured value, normalized, with time tag
    M_ME_NB_1 = 11    # Measured value, scaled
    M_ME_TB_1 = 12    # Measured value, scaled, with time tag
    M_ME_NC_1 = 13    # Measured value, short float (IEEE 754)
    M_ME_TC_1 = 14    # Measured value, short float, with time tag
    M_IT_NA_1 = 15    # Integrated totals (counter)
    M_IT_TA_1 = 16    # Integrated totals with time tag
    M_PS_NA_1 = 20    # Packed single-point with status change detection
    M_ME_ND_1 = 21    # Measured value, normalized, no quality descriptor
    # --- with CP56Time2a (7-octet) time tags ---
    M_SP_TB_1 = 30    # Single-point with CP56Time2a
    M_DP_TB_1 = 31    # Double-point with CP56Time2a
    M_ST_TB_1 = 32    # Step position with CP56Time2a
    M_BO_TB_1 = 33    # Bitstring with CP56Time2a
    M_ME_TD_1 = 34    # Measured normalized with CP56Time2a
    M_ME_TE_1 = 35    # Measured scaled with CP56Time2a
    M_ME_TF_1 = 36    # Measured short float with CP56Time2a
    M_IT_TB_1 = 37    # Integrated totals with CP56Time2a
    M_EP_TD_1 = 38    # Event of protection equipment with CP56Time2a
    # --- Process information in control direction ---
    C_SC_NA_1 = 45    # Single command
    C_DC_NA_1 = 46    # Double command
    C_RC_NA_1 = 47    # Regulating step command
    C_SE_NA_1 = 48    # Set-point command, normalized
    C_SE_NB_1 = 49    # Set-point command, scaled
    C_SE_NC_1 = 50    # Set-point command, short float
    C_BO_NA_1 = 51    # Bitstring of 32 bit command
    C_SC_TA_1 = 58    # Single command with CP56Time2a
    C_DC_TA_1 = 59    # Double command with CP56Time2a
    C_RC_TA_1 = 60    # Regulating step command with CP56Time2a
    C_SE_TA_1 = 61    # Set-point normalized with CP56Time2a
    C_SE_TB_1 = 62    # Set-point scaled with CP56Time2a
    C_SE_TC_1 = 63    # Set-point short float with CP56Time2a
    # --- System information in monitor / control direction ---
    M_EI_NA_1 = 70    # End of initialization
    C_IC_NA_1 = 100   # (General) interrogation command
    C_CI_NA_1 = 101   # Counter interrogation command
    C_RD_NA_1 = 102   # Read command
    C_CS_NA_1 = 103   # Clock synchronization command
    C_TS_NA_1 = 104   # Test command
    C_RP_NA_1 = 105   # Reset process command
    C_CD_NA_1 = 106   # Delay acquisition command
    # --- Parameter / file transfer ---
    P_ME_NA_1 = 110   # Parameter of measured value, normalized
    P_ME_NB_1 = 111   # Parameter of measured value, scaled
    P_ME_NC_1 = 112   # Parameter of measured value, short float
    P_AC_NA_1 = 113   # Parameter activation
    F_FR_NA_1 = 120   # File ready
    F_SR_NA_1 = 121   # Section ready
    F_SC_NA_1 = 122   # Call directory / select file / call file / call section
    F_LS_NA_1 = 123   # Last section / last segment
    F_AF_NA_1 = 124   # Ack file / ack section
    F_SG_NA_1 = 125   # Segment
    F_DR_TA_1 = 126   # Directory


# Human readable names keyed by the numeric type id.
TYPE_NAMES = {
    1: "M_SP_NA_1", 2: "M_SP_TA_1", 3: "M_DP_NA_1", 4: "M_DP_TA_1",
    5: "M_ST_NA_1", 6: "M_ST_TA_1", 7: "M_BO_NA_1", 8: "M_BO_TA_1",
    9: "M_ME_NA_1", 10: "M_ME_TA_1", 11: "M_ME_NB_1", 12: "M_ME_TB_1",
    13: "M_ME_NC_1", 14: "M_ME_TC_1", 15: "M_IT_NA_1", 16: "M_IT_TA_1",
    20: "M_PS_NA_1", 21: "M_ME_ND_1",
    30: "M_SP_TB_1", 31: "M_DP_TB_1", 32: "M_ST_TB_1", 33: "M_BO_TB_1",
    34: "M_ME_TD_1", 35: "M_ME_TE_1", 36: "M_ME_TF_1", 37: "M_IT_TB_1",
    38: "M_EP_TD_1",
    45: "C_SC_NA_1", 46: "C_DC_NA_1", 47: "C_RC_NA_1", 48: "C_SE_NA_1",
    49: "C_SE_NB_1", 50: "C_SE_NC_1", 51: "C_BO_NA_1",
    58: "C_SC_TA_1", 59: "C_DC_TA_1", 60: "C_RC_TA_1", 61: "C_SE_TA_1",
    62: "C_SE_TB_1", 63: "C_SE_TC_1",
    70: "M_EI_NA_1",
    100: "C_IC_NA_1", 101: "C_CI_NA_1", 102: "C_RD_NA_1", 103: "C_CS_NA_1",
    104: "C_TS_NA_1", 105: "C_RP_NA_1", 106: "C_CD_NA_1",
    110: "P_ME_NA_1", 111: "P_ME_NB_1", 112: "P_ME_NC_1", 113: "P_AC_NA_1",
    120: "F_FR_NA_1", 121: "F_SR_NA_1", 122: "F_SC_NA_1", 123: "F_LS_NA_1",
    124: "F_AF_NA_1", 125: "F_SG_NA_1", 126: "F_DR_TA_1",
}

# Short descriptions used by the UI / tracer.
TYPE_DESC = {
    1: "Single-point", 3: "Double-point", 5: "Step position",
    7: "Bitstring 32", 9: "Measured normalized", 11: "Measured scaled",
    13: "Measured float", 15: "Counter", 20: "Packed single-point",
    21: "Measured norm (no QDS)",
    30: "Single-point +time", 31: "Double-point +time", 32: "Step +time",
    34: "Meas norm +time", 35: "Meas scaled +time", 36: "Meas float +time",
    37: "Counter +time", 38: "Protection event +time",
    45: "Single command", 46: "Double command", 47: "Step command",
    48: "Setpoint normalized", 49: "Setpoint scaled", 50: "Setpoint float",
    58: "Single cmd +time", 59: "Double cmd +time", 60: "Step cmd +time",
    61: "Setpoint norm +time", 62: "Setpoint scaled +time", 63: "Setpoint float +time",
    70: "End of initialization",
    100: "Interrogation", 101: "Counter interrogation", 102: "Read",
    103: "Clock sync", 104: "Test command", 105: "Reset process",
    106: "Delay acquisition",
}


# ---------------------------------------------------------------------------
# Cause Of Transmission (COT) - IEC 60870-5-101 clause 7.2.3
# ---------------------------------------------------------------------------
class COT:
    PERIODIC = 1
    BACKGROUND = 2
    SPONTANEOUS = 3
    INITIALIZED = 4
    REQUEST = 5
    ACTIVATION = 6
    ACT_CON = 7            # activation confirmation
    DEACTIVATION = 8
    DEACT_CON = 9          # deactivation confirmation
    ACT_TERM = 10          # activation termination
    RETREM = 11            # return info caused by remote command
    RETLOC = 12            # return info caused by local command
    FILE = 13
    INTROGEN = 20          # interrogated by station interrogation
    INTRO_GROUP_1 = 21     # interrogated by group 1 ... 16 follow (21..36)
    REQCOGEN = 37          # requested by general counter request
    REQCO1 = 38            # requested by group 1 counter ... (38..41)
    UNKNOWN_TYPE = 44
    UNKNOWN_CAUSE = 45
    UNKNOWN_ASDU_ADDR = 46
    UNKNOWN_OBJECT_ADDR = 47


COT_NAMES = {
    1: "periodic", 2: "background", 3: "spontaneous", 4: "initialized",
    5: "request", 6: "activation", 7: "act-con", 8: "deactivation",
    9: "deact-con", 10: "act-term", 11: "ret-remote", 12: "ret-local",
    13: "file", 20: "interrogated-station",
    21: "interrogated-grp1", 22: "interrogated-grp2", 23: "interrogated-grp3",
    24: "interrogated-grp4", 25: "interrogated-grp5", 26: "interrogated-grp6",
    27: "interrogated-grp7", 28: "interrogated-grp8", 29: "interrogated-grp9",
    30: "interrogated-grp10", 31: "interrogated-grp11", 32: "interrogated-grp12",
    33: "interrogated-grp13", 34: "interrogated-grp14", 35: "interrogated-grp15",
    36: "interrogated-grp16",
    37: "req-counter-gen", 38: "req-counter-grp1", 39: "req-counter-grp2",
    40: "req-counter-grp3", 41: "req-counter-grp4",
    44: "unknown-type-id", 45: "unknown-cause", 46: "unknown-asdu-addr",
    47: "unknown-object-addr",
}


# ---------------------------------------------------------------------------
# Qualifier of interrogation (QOI) groups
# ---------------------------------------------------------------------------
class QOI:
    STATION = 20          # global / station interrogation
    GROUP_1 = 21          # groups 1..16 are 21..36
    # ... up to GROUP_16 = 36


# Double-point state values (DIU - Double Point Information)
class DPI:
    INDETERMINATE_0 = 0   # indeterminate or intermediate
    OFF = 1               # determined OFF / open
    ON = 2                # determined ON / closed
    INDETERMINATE_3 = 3   # indeterminate


DPI_NAMES = {0: "intermediate", 1: "OFF", 2: "ON", 3: "indeterminate"}


# Single command / double command qualifier
class SelectExecute:
    EXECUTE = 0
    SELECT = 1


# Quality descriptor (QDS) bit flags - shared by many monitor ASDUs.
class QDS:
    OV = 0x01   # overflow
    BL = 0x10   # blocked
    SB = 0x20   # substituted
    NT = 0x40   # not topical
    IV = 0x80   # invalid


def qds_to_text(q: int) -> str:
    """Return a compact human string describing the set QDS flags."""
    flags = []
    if q & QDS.IV:
        flags.append("IV")
    if q & QDS.NT:
        flags.append("NT")
    if q & QDS.SB:
        flags.append("SB")
    if q & QDS.BL:
        flags.append("BL")
    if q & QDS.OV:
        flags.append("OV")
    return "|".join(flags) if flags else "good"
