# -*- coding: utf-8 -*-
"""
FT1.2 frame format (IEC 60870-5-1) encode / decode.

IEC 60870-5-101 uses the FT1.2 asynchronous frame format. Three shapes exist:

  * Single control character .......... 1 byte  (0xE5 / 0xA2)
  * Fixed length frame ................ 10h C A ... CS 16h
  * Variable length frame ............. 68h L L 68h C A [ASDU] CS 16h

where C = control field, A = link address (1 or 2 octets), L = length of the
user data (control field + address + ASDU), CS = arithmetic checksum (sum of
all user-data octets modulo 256).

The decoder is written as an incremental parser so it can be fed the raw byte
stream coming off a serial port one chunk at a time.
"""

from .constants import (
    START_FIXED, START_VARIABLE, STOP, SINGLE_CHAR_E5, SINGLE_CHAR_A2,
)


class FrameError(Exception):
    """Raised when a frame fails structural or checksum validation."""


def checksum(data: bytes) -> int:
    """Arithmetic sum of octets modulo 256 (the FT1.2 CS field)."""
    return sum(data) & 0xFF


class Frame:
    """A decoded (or to-be-encoded) FT1.2 frame."""

    SINGLE = "single"
    FIXED = "fixed"
    VARIABLE = "variable"

    def __init__(self, kind, control=0, address=0, asdu=b"",
                 addr_len=1, single_value=SINGLE_CHAR_E5):
        self.kind = kind
        self.control = control
        self.address = address
        self.asdu = bytes(asdu)
        self.addr_len = addr_len
        self.single_value = single_value

    # -- builders -----------------------------------------------------------
    @classmethod
    def single(cls, value=SINGLE_CHAR_E5):
        return cls(cls.SINGLE, single_value=value)

    @classmethod
    def fixed(cls, control, address, addr_len=1):
        return cls(cls.FIXED, control=control, address=address, addr_len=addr_len)

    @classmethod
    def variable(cls, control, address, asdu, addr_len=1):
        return cls(cls.VARIABLE, control=control, address=address,
                   asdu=asdu, addr_len=addr_len)

    # -- encode -------------------------------------------------------------
    def _addr_bytes(self) -> bytes:
        if self.addr_len == 1:
            return bytes([self.address & 0xFF])
        return bytes([self.address & 0xFF, (self.address >> 8) & 0xFF])

    def encode(self) -> bytes:
        if self.kind == self.SINGLE:
            return bytes([self.single_value])

        if self.kind == self.FIXED:
            user = bytes([self.control & 0xFF]) + self._addr_bytes()
            return bytes([START_FIXED]) + user + bytes([checksum(user), STOP])

        if self.kind == self.VARIABLE:
            user = bytes([self.control & 0xFF]) + self._addr_bytes() + self.asdu
            length = len(user)
            if length > 255:
                raise FrameError("variable frame user data exceeds 255 octets")
            return (bytes([START_VARIABLE, length, length, START_VARIABLE])
                    + user + bytes([checksum(user), STOP]))

        raise FrameError(f"unknown frame kind: {self.kind}")

    def __repr__(self):
        return (f"<Frame {self.kind} C=0x{self.control:02X} "
                f"A={self.address} asdu={len(self.asdu)}B>")


class FrameDecoder:
    """
    Incremental FT1.2 decoder.

    Feed raw bytes with ``feed(data)``; it yields complete ``Frame`` objects as
    they are recognised. Malformed leading bytes are skipped so the decoder
    re-synchronises instead of getting stuck.
    """

    def __init__(self, addr_len=1):
        self.addr_len = addr_len
        self._buf = bytearray()

    def feed(self, data: bytes):
        self._buf.extend(data)
        frames = []
        while True:
            frame, consumed = self._try_parse()
            if frame is None and consumed == 0:
                break
            if consumed:
                del self._buf[:consumed]
            if frame is not None:
                frames.append(frame)
        return frames

    def _try_parse(self):
        buf = self._buf
        if not buf:
            return None, 0

        b0 = buf[0]

        # single control character ----------------------------------------
        if b0 in (SINGLE_CHAR_E5, SINGLE_CHAR_A2):
            return Frame.single(b0), 1

        # fixed length frame ----------------------------------------------
        if b0 == START_FIXED:
            need = 1 + 1 + self.addr_len + 1 + 1  # start C addr cs stop
            if len(buf) < need:
                return None, 0
            user = bytes(buf[1:1 + 1 + self.addr_len])
            cs = buf[1 + 1 + self.addr_len]
            stop = buf[2 + 1 + self.addr_len]
            if stop != STOP or cs != checksum(user):
                return None, 1  # desync: drop one byte and retry
            control = user[0]
            address = self._decode_addr(user[1:])
            return Frame.fixed(control, address, self.addr_len), need

        # variable length frame -------------------------------------------
        if b0 == START_VARIABLE:
            if len(buf) < 4:
                return None, 0
            l1, l2, start2 = buf[1], buf[2], buf[3]
            if l1 != l2 or start2 != START_VARIABLE or l1 < (1 + self.addr_len):
                return None, 1
            total = 4 + l1 + 2   # 2x start + 2 len + user + cs + stop
            if len(buf) < total:
                return None, 0
            user = bytes(buf[4:4 + l1])
            cs = buf[4 + l1]
            stop = buf[5 + l1]
            if stop != STOP or cs != checksum(user):
                return None, 1
            control = user[0]
            address = self._decode_addr(user[1:1 + self.addr_len])
            asdu = user[1 + self.addr_len:]
            return Frame.variable(control, address, asdu, self.addr_len), total

        # unknown leading byte: discard it
        return None, 1

    def _decode_addr(self, raw: bytes) -> int:
        if self.addr_len == 1:
            return raw[0]
        return raw[0] | (raw[1] << 8)

    def pending(self) -> int:
        return len(self._buf)

    def reset(self):
        self._buf.clear()
