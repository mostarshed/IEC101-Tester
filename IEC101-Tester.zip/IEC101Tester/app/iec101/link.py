# -*- coding: utf-8 -*-
"""
IEC 60870-5-101 link layer master.

Implements the controlling-station side of the link in both unbalanced and
balanced transmission procedures:

  * unbalanced: the master polls the outstation for class-1 (events) and
    class-2 (cyclic) data, driving the FCB toggle per outstation.
  * balanced: both stations may initiate; the master still toggles its own FCB.

The master runs its own thread with a transmit queue for user data (ASDUs) and
a periodic poll cycle. Every byte in and out, and every decoded frame / ASDU,
is reported through the ``on_event`` callback so the web tracer can show it.
"""

import threading
import time
import queue
import datetime

from .frame import Frame, FrameDecoder
from .asdu import ASDU, decode_asdu, encode_asdu, Sizes
from .constants import (
    CF_PRM, CF_FCB, CF_FCV, CF_ACD, CF_DFC,
    PrimaryFunction, SecondaryFunction, SINGLE_CHAR_E5,
)


def _now_iso():
    return datetime.datetime.now().isoformat(timespec="milliseconds")


class LinkEvent:
    """A structured event pushed to subscribers (tracer / logger)."""
    def __init__(self, kind, direction=None, raw=b"", frame=None,
                 asdu=None, text="", level="info"):
        self.ts = _now_iso()
        self.kind = kind            # 'raw' | 'frame' | 'asdu' | 'log' | 'state'
        self.direction = direction  # 'tx' | 'rx' | None
        self.raw = raw
        self.frame = frame
        self.asdu = asdu
        self.text = text
        self.level = level          # debug|info|warn|error

    def to_dict(self):
        d = {"ts": self.ts, "kind": self.kind, "direction": self.direction,
             "level": self.level, "text": self.text}
        if self.raw:
            d["hex"] = self.raw.hex(" ")
            d["len"] = len(self.raw)
        if self.frame is not None:
            d["frame"] = {
                "kind": self.frame.kind,
                "control": self.frame.control,
                "prm": bool(self.frame.control & CF_PRM),
                "fcb": bool(self.frame.control & CF_FCB),
                "fcv": bool(self.frame.control & CF_FCV),
                "acd": bool(self.frame.control & CF_ACD),
                "dfc": bool(self.frame.control & CF_DFC),
                "function": self.frame.control & 0x0F,
                "address": self.frame.address,
            }
        if self.asdu is not None:
            d["asdu"] = self.asdu.to_dict()
        return d


class LinkMaster:
    def __init__(self, transport, config, on_event=None):
        self.transport = transport
        self.cfg = config
        self.on_event = on_event or (lambda e: None)
        self.sizes = Sizes(cot_len=config.get("cot_len", 2),
                           common_len=config.get("common_len", 2),
                           ioa_len=config.get("ioa_len", 3))
        self.link_addr = config.get("link_address", 1)
        self.addr_len = config.get("link_addr_len", 2)
        self.balanced = config.get("balanced", False)
        self.poll_interval = config.get("poll_interval", 1.0)

        self._decoder = FrameDecoder(addr_len=self.addr_len)
        self._fcb = False
        self._tx_queue = queue.Queue()
        self._reply = queue.Queue()
        self._running = False
        self._thread = None
        self._link_up = False
        self._lock = threading.Lock()
        self.stats = {"tx_frames": 0, "rx_frames": 0, "tx_asdu": 0,
                      "rx_asdu": 0, "timeouts": 0, "errors": 0}

    # -- lifecycle ----------------------------------------------------------
    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True,
                                        name="iec101-master")
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)
        self._link_up = False
        self._emit_state()

    @property
    def link_up(self):
        return self._link_up

    # -- public send API ----------------------------------------------------
    def send_asdu(self, asdu: ASDU):
        """Queue an application ASDU for transmission (confirmed user data)."""
        asdu.sizes = self.sizes
        self._tx_queue.put(asdu)

    # -- internal helpers ---------------------------------------------------
    def _log(self, text, level="info"):
        self.on_event(LinkEvent("log", text=text, level=level))

    def _emit_state(self):
        self.on_event(LinkEvent("state", text="link_up" if self._link_up
                                else "link_down",
                                level="info" if self._link_up else "warn"))

    def _control(self, function, fcb=False, fcv=False):
        c = CF_PRM | (function & 0x0F)
        if fcv:
            c |= CF_FCV
        if fcb:
            c |= CF_FCB
        return c

    def _send_frame(self, frame: Frame):
        raw = frame.encode()
        self.transport.write(raw)
        self.stats["tx_frames"] += 1
        self.on_event(LinkEvent("frame", direction="tx", raw=raw, frame=frame))

    def _read_response(self, timeout=None):
        """Block until one frame is decoded from the transport, or timeout."""
        timeout = self.cfg.get("response_timeout", 1.0) if timeout is None else timeout
        deadline = time.time() + timeout
        while time.time() < deadline and self._running:
            data = self.transport.read(256, timeout=0.05)
            if data:
                self.on_event(LinkEvent("raw", direction="rx", raw=data))
                for fr in self._decoder.feed(data):
                    self.stats["rx_frames"] += 1
                    self._annotate_rx(fr)
                    return fr
        self.stats["timeouts"] += 1
        return None

    def _annotate_rx(self, fr: Frame):
        asdu = None
        if fr.kind == Frame.VARIABLE and fr.asdu:
            try:
                asdu = decode_asdu(fr.asdu, self.sizes)
                self.stats["rx_asdu"] += 1
            except Exception as exc:          # noqa: BLE001
                self._log(f"ASDU decode error: {exc}", "error")
                self.stats["errors"] += 1
        self.on_event(LinkEvent("frame", direction="rx", raw=fr.encode(),
                                frame=fr, asdu=asdu))
        return asdu

    # -- link procedures ----------------------------------------------------
    def _reset_link(self):
        self._log("Reset of remote link (SEND/CONFIRM)…")
        frame = Frame.fixed(self._control(PrimaryFunction.RESET_REMOTE_LINK),
                            self.link_addr, self.addr_len)
        self._send_frame(frame)
        resp = self._read_response()
        if resp is None:
            self._log("No response to reset link", "warn")
            return False
        self._fcb = True   # first user data / poll after reset carries FCB=1
        self._link_up = True
        self._emit_state()
        self._log("Link reset confirmed (ACK E5/fixed).", "info")
        return True

    def _request_link_status(self):
        frame = Frame.fixed(self._control(PrimaryFunction.REQ_LINK_STATUS),
                            self.link_addr, self.addr_len)
        self._send_frame(frame)
        return self._read_response()

    def _poll_class(self, class1=True):
        func = (PrimaryFunction.REQ_CLASS1_DATA if class1
                else PrimaryFunction.REQ_CLASS2_DATA)
        frame = Frame.fixed(self._control(func, fcb=self._fcb, fcv=True),
                            self.link_addr, self.addr_len)
        self._send_frame(frame)
        self._fcb = not self._fcb
        resp = self._read_response()
        return resp

    def _send_user_data(self, asdu: ASDU):
        payload = encode_asdu(asdu)
        self.stats["tx_asdu"] += 1
        self.on_event(LinkEvent("asdu", direction="tx", asdu=asdu,
                                text=f"TX {asdu.type_name} COT={asdu.cot_name}"))
        control = self._control(PrimaryFunction.USER_DATA_CONFIRM,
                                fcb=self._fcb, fcv=True)
        frame = Frame.variable(control, self.link_addr, payload, self.addr_len)
        self._send_frame(frame)
        self._fcb = not self._fcb
        resp = self._read_response()
        if resp is None:
            self._log(f"No link confirm for {asdu.type_name}", "warn")
        return resp

    # -- main loop ----------------------------------------------------------
    def _run(self):
        self._log("Master thread started.")
        # bring the link up
        try:
            if self.balanced:
                self._reset_link()
            else:
                self._request_link_status()
                self._reset_link()
        except Exception as exc:              # noqa: BLE001
            self._log(f"Link bring-up error: {exc}", "error")

        last_poll = 0.0
        while self._running:
            # 1) flush any queued user data (commands, interrogation…)
            try:
                asdu = self._tx_queue.get_nowait()
                self._send_user_data(asdu)
                continue
            except queue.Empty:
                pass

            # 2) periodic polling in unbalanced mode
            now = time.time()
            if not self.balanced and (now - last_poll) >= self.poll_interval:
                last_poll = now
                if not self._link_up:
                    self._reset_link()
                else:
                    self._poll_class(class1=True)
                    self._poll_class(class1=False)
            else:
                # in balanced mode just listen for spontaneous traffic
                resp = self._read_response(timeout=0.2)
                if resp is not None and resp.kind == Frame.VARIABLE:
                    # confirm received user data
                    ack = Frame.fixed(SecondaryFunction.ACK, self.link_addr,
                                      self.addr_len)
                    self._send_frame(ack)
            time.sleep(0.01)
        self._log("Master thread stopped.")
