# -*- coding: utf-8 -*-
"""
ASDU (Application Service Data Unit) encode / decode for IEC 60870-5-101.

An ASDU is laid out as:

    TypeID | VSQ | COT (+originator) | CommonAddress | [information objects]

VSQ (variable structure qualifier): bit7 = SQ (sequence), bits0..6 = number of
objects. When SQ = 1 the information object address is given once and the
following objects are implicitly at ioa, ioa+1, ...

The address field sizes (COT, originator, common-address, IOA) are configurable
in IEC 101; this implementation keeps them in a ``Sizes`` descriptor that is
threaded through encode / decode so the same code works for the common
1/1/2/2 and 2/0/1/2 profiles used by substation gateways.
"""

import struct
import datetime
from typing import Any, Optional, List
from dataclasses import dataclass, field
from .constants import TypeID, TYPE_NAMES, COT_NAMES, qds_to_text, DPI_NAMES
from . import timetag


@dataclass
class Sizes:
    cot_len: int = 1          # 1 or 2 (2 means originator address present)
    common_len: int = 2       # 1 or 2 (ASDU / common address of ASDU)
    ioa_len: int = 3          # 1, 2 or 3 (information object address)

    @property
    def originator_present(self) -> bool:
        return self.cot_len == 2


@dataclass
class InfoObject:
    """One information object inside an ASDU."""
    ioa: int
    value: Any = None         # interpreted value (bool, int, float, tuple...)
    quality: int = 0          # QDS / quality byte where applicable
    time: Optional[datetime.datetime] = None  # for time-tagged objects
    raw: bytes = b""          # raw payload bytes for diagnostics

    def to_dict(self):
        d = {"ioa": self.ioa, "value": self.value, "quality": self.quality,
             "quality_text": qds_to_text(self.quality)}
        if self.time is not None:
            d["time"] = self.time.isoformat(timespec="milliseconds")
        return d


@dataclass
class ASDU:
    type_id: int
    cot: int
    common_address: int
    objects: List[InfoObject] = field(default_factory=list)
    sq: bool = False
    originator: int = 0
    test: bool = False        # T bit in COT
    negative: bool = False    # P/N bit in COT
    sizes: Sizes = field(default_factory=Sizes)

    @property
    def type_name(self):
        return TYPE_NAMES.get(self.type_id, f"TYPE_{self.type_id}")

    @property
    def cot_name(self):
        return COT_NAMES.get(self.cot, str(self.cot))

    def to_dict(self):
        return {
            "type_id": self.type_id,
            "type_name": self.type_name,
            "cot": self.cot,
            "cot_name": self.cot_name,
            "negative": self.negative,
            "test": self.test,
            "originator": self.originator,
            "common_address": self.common_address,
            "sq": self.sq,
            "objects": [o.to_dict() for o in self.objects],
        }


# ---------------------------------------------------------------------------
# small helpers for little-endian address fields
# ---------------------------------------------------------------------------
def _enc_uint(value: int, nbytes: int) -> bytes:
    return bytes((value >> (8 * i)) & 0xFF for i in range(nbytes))


def _dec_uint(raw: bytes) -> int:
    return sum(b << (8 * i) for i, b in enumerate(raw))


# normalized value <-> float in range [-1, 1)
def _enc_nva(value: float) -> bytes:
    v = int(round(max(-1.0, min(0.999969, value)) * 32768.0))
    return struct.pack("<h", v)


def _dec_nva(raw: bytes) -> float:
    return struct.unpack("<h", raw)[0] / 32768.0


# ===========================================================================
#  Encoding of information objects, keyed by type id
# ===========================================================================
# time-tagged monitor types share the payload layout of a base type, with a
# CP56Time2a appended. Map each to the base type so value encoding is reused.
_TIME_BASE = {
    TypeID.M_SP_TB_1: TypeID.M_SP_NA_1, TypeID.M_DP_TB_1: TypeID.M_DP_NA_1,
    TypeID.M_ST_TB_1: TypeID.M_ST_NA_1, TypeID.M_BO_TB_1: TypeID.M_BO_NA_1,
    TypeID.M_ME_TD_1: TypeID.M_ME_NA_1, TypeID.M_ME_TE_1: TypeID.M_ME_NB_1,
    TypeID.M_ME_TF_1: TypeID.M_ME_NC_1, TypeID.M_IT_TB_1: TypeID.M_IT_NA_1,
}


def _encode_object(type_id: int, obj: InfoObject, sizes: Sizes,
                   include_ioa: bool) -> bytes:
    out = bytearray()
    if include_ioa:
        out += _enc_uint(obj.ioa, sizes.ioa_len)

    # encode the value using the base type's layout for time-tagged variants
    t = _TIME_BASE.get(type_id, type_id)
    if t == TypeID.M_SP_NA_1:                       # single point
        siq = (1 if obj.value else 0) | (obj.quality & 0xF0)
        out.append(siq)
    elif t == TypeID.M_DP_NA_1:                     # double point
        diq = (int(obj.value) & 0x03) | (obj.quality & 0xF0)
        out.append(diq)
    elif t == TypeID.M_ST_NA_1:                     # step position
        out.append(int(obj.value) & 0x7F)
        out.append(obj.quality & 0xFF)
    elif t == TypeID.M_BO_NA_1:                     # bitstring 32
        out += struct.pack("<I", int(obj.value) & 0xFFFFFFFF)
        out.append(obj.quality & 0xFF)
    elif t in (TypeID.M_ME_NA_1, TypeID.M_ME_ND_1): # normalized
        out += _enc_nva(float(obj.value))
        if t == TypeID.M_ME_NA_1:
            out.append(obj.quality & 0xFF)
    elif t == TypeID.M_ME_NB_1:                     # scaled
        out += struct.pack("<h", int(obj.value))
        out.append(obj.quality & 0xFF)
    elif t == TypeID.M_ME_NC_1:                     # short float
        out += struct.pack("<f", float(obj.value))
        out.append(obj.quality & 0xFF)
    elif t == TypeID.M_IT_NA_1:                     # counter
        out += struct.pack("<i", int(obj.value))
        out.append(obj.quality & 0xFF)
    # --- commands in control direction ---
    elif t == TypeID.C_SC_NA_1:                     # single command
        sco = (1 if obj.value else 0) | ((obj.quality & 0x1F) << 2)
        out.append(sco)
    elif t == TypeID.C_DC_NA_1:                     # double command
        dco = (int(obj.value) & 0x03) | ((obj.quality & 0x1F) << 2)
        out.append(dco)
    elif t == TypeID.C_RC_NA_1:                     # regulating step
        rco = (int(obj.value) & 0x03) | ((obj.quality & 0x1F) << 2)
        out.append(rco)
    elif t == TypeID.C_SE_NA_1:                     # setpoint normalized
        out += _enc_nva(float(obj.value))
        out.append(obj.quality & 0xFF)              # QOS
    elif t == TypeID.C_SE_NB_1:                     # setpoint scaled
        out += struct.pack("<h", int(obj.value))
        out.append(obj.quality & 0xFF)
    elif t == TypeID.C_SE_NC_1:                     # setpoint float
        out += struct.pack("<f", float(obj.value))
        out.append(obj.quality & 0xFF)
    elif t == TypeID.C_IC_NA_1:                     # interrogation
        out.append(int(obj.value) & 0xFF)           # QOI
    elif t == TypeID.C_CI_NA_1:                     # counter interrogation
        out.append(int(obj.value) & 0xFF)           # QCC
    elif t == TypeID.C_RD_NA_1:                     # read command (no payload)
        pass
    elif t == TypeID.C_CS_NA_1:                     # clock sync (CP56Time2a)
        out += timetag.encode_cp56(obj.time)
    elif t == TypeID.C_TS_NA_1:                     # test command
        out += struct.pack("<H", int(obj.value) if obj.value else 0xAA55)
    elif t == TypeID.C_RP_NA_1:                     # reset process
        out.append(int(obj.value) & 0xFF)           # QRP
    elif t in (TypeID.M_EI_NA_1,):                  # end of init
        out.append(int(obj.value) & 0xFF)
    else:
        # fall back to raw bytes if the caller supplied them
        out += obj.raw

    # append CP56Time2a for the time-tagged monitor types
    if type_id in _TIME_BASE:
        out += timetag.encode_cp56(obj.time)
    return bytes(out)


def encode_asdu(a: ASDU) -> bytes:
    sizes = a.sizes
    vsq = (len(a.objects) & 0x7F) | (0x80 if a.sq else 0)
    cot = (a.cot & 0x3F) | (0x40 if a.negative else 0) | (0x80 if a.test else 0)

    out = bytearray()
    out.append(a.type_id & 0xFF)
    out.append(vsq)
    out.append(cot)
    if sizes.originator_present:
        out.append(a.originator & 0xFF)
    out += _enc_uint(a.common_address, sizes.common_len)

    if a.sq and a.objects:
        # single IOA then packed values
        out += _enc_uint(a.objects[0].ioa, sizes.ioa_len)
        for i, obj in enumerate(a.objects):
            out += _encode_object(a.type_id, obj, sizes, include_ioa=False)
    else:
        for obj in a.objects:
            out += _encode_object(a.type_id, obj, sizes, include_ioa=True)
    return bytes(out)


# ===========================================================================
#  Decoding
# ===========================================================================
# number of payload bytes (excluding the IOA) for each monitor/control type
_ELEMENT_LEN = {
    TypeID.M_SP_NA_1: 1, TypeID.M_DP_NA_1: 1, TypeID.M_ST_NA_1: 2,
    TypeID.M_BO_NA_1: 5, TypeID.M_ME_NA_1: 3, TypeID.M_ME_ND_1: 2,
    TypeID.M_ME_NB_1: 3, TypeID.M_ME_NC_1: 5, TypeID.M_IT_NA_1: 5,
    TypeID.M_SP_TB_1: 1 + 7, TypeID.M_DP_TB_1: 1 + 7, TypeID.M_ST_TB_1: 2 + 7,
    TypeID.M_ME_TD_1: 3 + 7, TypeID.M_ME_TE_1: 3 + 7, TypeID.M_ME_TF_1: 5 + 7,
    TypeID.M_IT_TB_1: 5 + 7, TypeID.M_BO_TB_1: 5 + 7,
    TypeID.C_SC_NA_1: 1, TypeID.C_DC_NA_1: 1, TypeID.C_RC_NA_1: 1,
    TypeID.C_SE_NA_1: 3, TypeID.C_SE_NB_1: 3, TypeID.C_SE_NC_1: 5,
    TypeID.C_IC_NA_1: 1, TypeID.C_CI_NA_1: 1, TypeID.C_RD_NA_1: 0,
    TypeID.C_CS_NA_1: 7, TypeID.C_TS_NA_1: 2, TypeID.C_RP_NA_1: 1,
    TypeID.M_EI_NA_1: 1,
}


def _decode_object(type_id: int, payload: bytes) -> InfoObject:
    """Interpret the per-object payload (IOA already stripped)."""
    o = InfoObject(ioa=0, raw=payload)
    t = type_id
    has_time = t in (TypeID.M_SP_TB_1, TypeID.M_DP_TB_1, TypeID.M_ST_TB_1,
                     TypeID.M_ME_TD_1, TypeID.M_ME_TE_1, TypeID.M_ME_TF_1,
                     TypeID.M_IT_TB_1, TypeID.M_BO_TB_1)
    body = payload[:-7] if has_time else payload
    if has_time:
        o.time = timetag.decode_cp56(payload[-7:])

    if t in (TypeID.M_SP_NA_1, TypeID.M_SP_TB_1):
        siq = body[0]
        o.value = bool(siq & 0x01)
        o.quality = siq & 0xF0
    elif t in (TypeID.M_DP_NA_1, TypeID.M_DP_TB_1):
        diq = body[0]
        o.value = diq & 0x03
        o.quality = diq & 0xF0
    elif t in (TypeID.M_ST_NA_1, TypeID.M_ST_TB_1):
        o.value = body[0] & 0x7F
        if o.value & 0x40:
            o.value -= 128  # value is signed 7-bit (VTI, -64..63)
        o.quality = body[1]
    elif t in (TypeID.M_BO_NA_1, TypeID.M_BO_TB_1):
        o.value = struct.unpack("<I", body[0:4])[0]
        o.quality = body[4]
    elif t == TypeID.M_ME_NA_1:
        o.value = round(_dec_nva(body[0:2]), 6)
        o.quality = body[2]
    elif t == TypeID.M_ME_ND_1:
        o.value = round(_dec_nva(body[0:2]), 6)
        o.quality = 0
    elif t == TypeID.M_ME_TD_1:
        o.value = round(_dec_nva(body[0:2]), 6)
        o.quality = body[2]
    elif t == TypeID.M_ME_NB_1:
        o.value = struct.unpack("<h", body[0:2])[0]
        o.quality = body[2]
    elif t == TypeID.M_ME_TE_1:
        o.value = struct.unpack("<h", body[0:2])[0]
        o.quality = body[2]
    elif t == TypeID.M_ME_NC_1:
        o.value = round(struct.unpack("<f", body[0:4])[0], 6)
        o.quality = body[4]
    elif t == TypeID.M_ME_TF_1:
        o.value = round(struct.unpack("<f", body[0:4])[0], 6)
        o.quality = body[4]
    elif t in (TypeID.M_IT_NA_1, TypeID.M_IT_TB_1):
        o.value = struct.unpack("<i", body[0:4])[0]
        o.quality = body[4]  # sequence notation / flags
    elif t == TypeID.C_SC_NA_1:
        o.value = bool(body[0] & 0x01)
        o.quality = (body[0] >> 2) & 0x1F
    elif t == TypeID.C_DC_NA_1:
        o.value = body[0] & 0x03
        o.quality = (body[0] >> 2) & 0x1F
    elif t == TypeID.C_RC_NA_1:
        o.value = body[0] & 0x03
        o.quality = (body[0] >> 2) & 0x1F
    elif t == TypeID.C_SE_NA_1:
        o.value = round(_dec_nva(body[0:2]), 6)
        o.quality = body[2]
    elif t == TypeID.C_SE_NB_1:
        o.value = struct.unpack("<h", body[0:2])[0]
        o.quality = body[2]
    elif t == TypeID.C_SE_NC_1:
        o.value = round(struct.unpack("<f", body[0:4])[0], 6)
        o.quality = body[4]
    elif t == TypeID.C_IC_NA_1:
        o.value = body[0]      # QOI
    elif t == TypeID.C_CI_NA_1:
        o.value = body[0]      # QCC
    elif t == TypeID.C_CS_NA_1:
        o.time = timetag.decode_cp56(body[0:7])
        o.value = "clock"
    elif t == TypeID.M_EI_NA_1:
        o.value = body[0]      # COI (cause of initialization)
    else:
        o.value = body.hex()
    return o


def decode_asdu(data: bytes, sizes: Sizes) -> ASDU:
    if len(data) < 2:
        raise ValueError("ASDU too short")
    idx = 0
    type_id = data[idx]; idx += 1
    vsq = data[idx]; idx += 1
    sq = bool(vsq & 0x80)
    count = vsq & 0x7F
    cot_raw = data[idx]; idx += 1
    cot = cot_raw & 0x3F
    negative = bool(cot_raw & 0x40)
    test = bool(cot_raw & 0x80)
    originator = 0
    if sizes.originator_present:
        originator = data[idx]; idx += 1
    common = _dec_uint(data[idx:idx + sizes.common_len]); idx += sizes.common_len

    a = ASDU(type_id=type_id, cot=cot, common_address=common, sq=sq,
             originator=originator, test=test, negative=negative, sizes=sizes)

    elen = _ELEMENT_LEN.get(type_id)
    if elen is None:
        # unknown type: keep the rest as a single raw object for inspection
        a.objects.append(InfoObject(ioa=0, value=data[idx:].hex(),
                                    raw=data[idx:]))
        return a

    if sq:
        base_ioa = _dec_uint(data[idx:idx + sizes.ioa_len]); idx += sizes.ioa_len
        for i in range(count):
            payload = data[idx:idx + elen]; idx += elen
            obj = _decode_object(type_id, payload)
            obj.ioa = base_ioa + i
            a.objects.append(obj)
    else:
        for _ in range(count):
            ioa = _dec_uint(data[idx:idx + sizes.ioa_len]); idx += sizes.ioa_len
            payload = data[idx:idx + elen]; idx += elen
            obj = _decode_object(type_id, payload)
            obj.ioa = ioa
            a.objects.append(obj)
    return a
