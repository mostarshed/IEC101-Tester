# -*- coding: utf-8 -*-
"""
High-level ASDU builders for the control direction.

These helpers turn a simple request from the UI ("send a double command CLOSE
to IOA 1001 with select-before-operate") into a fully formed ASDU ready for the
link layer. Keeping them here keeps the web layer free of protocol detail.
"""

import datetime
from .asdu import ASDU, InfoObject, Sizes
from .constants import TypeID, COT, QOI, SelectExecute


def _asdu(type_id, cot, common, objs, sizes, test=False):
    return ASDU(type_id=type_id, cot=cot, common_address=common,
                objects=objs, sizes=sizes, test=test)


def general_interrogation(common, sizes, group=20):
    """C_IC_NA_1 — group 20 = station (global) interrogation."""
    return _asdu(TypeID.C_IC_NA_1, COT.ACTIVATION, common,
                 [InfoObject(ioa=0, value=group)], sizes)


def counter_interrogation(common, sizes, qcc=5):
    """C_CI_NA_1 — qcc 5 = general request + freeze."""
    return _asdu(TypeID.C_CI_NA_1, COT.ACTIVATION, common,
                 [InfoObject(ioa=0, value=qcc)], sizes)


def clock_sync(common, sizes, when=None):
    return _asdu(TypeID.C_CS_NA_1, COT.ACTIVATION, common,
                 [InfoObject(ioa=0, value="clock",
                             time=when or datetime.datetime.now())], sizes)


def read_command(common, sizes, ioa):
    return _asdu(TypeID.C_RD_NA_1, COT.REQUEST, common,
                 [InfoObject(ioa=ioa, value=None)], sizes)


def test_command(common, sizes):
    return _asdu(TypeID.C_TS_NA_1, COT.ACTIVATION, common,
                 [InfoObject(ioa=0, value=0xAA55)], sizes)


def single_command(common, sizes, ioa, on, select=False, qu=0):
    qual = (qu & 0x1F) | (SelectExecute.SELECT if select else SelectExecute.EXECUTE)
    return _asdu(TypeID.C_SC_NA_1, COT.ACTIVATION, common,
                 [InfoObject(ioa=ioa, value=bool(on), quality=qual)], sizes)


def double_command(common, sizes, ioa, state, select=False, qu=0):
    """state: 1 = OFF/open, 2 = ON/close."""
    qual = (qu & 0x1F) | (SelectExecute.SELECT if select else SelectExecute.EXECUTE)
    return _asdu(TypeID.C_DC_NA_1, COT.ACTIVATION, common,
                 [InfoObject(ioa=ioa, value=int(state), quality=qual)], sizes)


def regulating_step(common, sizes, ioa, higher=True, select=False, qu=0):
    state = 2 if higher else 1
    qual = (qu & 0x1F) | (SelectExecute.SELECT if select else SelectExecute.EXECUTE)
    return _asdu(TypeID.C_RC_NA_1, COT.ACTIVATION, common,
                 [InfoObject(ioa=ioa, value=state, quality=qual)], sizes)


def setpoint_normalized(common, sizes, ioa, value, select=False, ql=0):
    qos = (ql & 0x7F) | (0x80 if select else 0x00)
    return _asdu(TypeID.C_SE_NA_1, COT.ACTIVATION, common,
                 [InfoObject(ioa=ioa, value=float(value), quality=qos)], sizes)


def setpoint_scaled(common, sizes, ioa, value, select=False, ql=0):
    qos = (ql & 0x7F) | (0x80 if select else 0x00)
    return _asdu(TypeID.C_SE_NB_1, COT.ACTIVATION, common,
                 [InfoObject(ioa=ioa, value=int(value), quality=qos)], sizes)


def setpoint_float(common, sizes, ioa, value, select=False, ql=0):
    qos = (ql & 0x7F) | (0x80 if select else 0x00)
    return _asdu(TypeID.C_SE_NC_1, COT.ACTIVATION, common,
                 [InfoObject(ioa=ioa, value=float(value), quality=qos)], sizes)


# dispatch table used by the REST layer
BUILDERS = {
    "interrogation": general_interrogation,
    "counter_interrogation": counter_interrogation,
    "clock_sync": clock_sync,
    "read": read_command,
    "test": test_command,
    "single": single_command,
    "double": double_command,
    "regulating": regulating_step,
    "setpoint_normalized": setpoint_normalized,
    "setpoint_scaled": setpoint_scaled,
    "setpoint_float": setpoint_float,
}
