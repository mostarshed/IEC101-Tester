# -*- coding: utf-8 -*-
"""
Commissioning report generator — produces a DOC (.docx) and a PDF report of an
IEC 60870-5-101 point-to-point test, suitable for sending to the client.

The report header carries the engineer, project, AOC and SCC names and the
substation details. The body lists every address grouped by its ASDU type, and
a dedicated section lists all switchgear (status points) with their state and
validity (quality).
"""

import os
import datetime
import tempfile

from iec101.constants import TYPE_NAMES, TYPE_DESC, DPI_NAMES, qds_to_text

REPORT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          "reports")
os.makedirs(REPORT_DIR, exist_ok=True)

TITLE = "IEC 60870-5-101 Gateway Commissioning Report"

# accent colour used in both outputs (control-room cyan / slate)
ACCENT = (0x12, 0x5a, 0x63)
SLATE = (0x1f, 0x2d, 0x3b)
GREEN = (0x1e, 0x7a, 0x3c)
RED = (0xb0, 0x2a, 0x30)


def _meta_rows(meta):
    """Ordered (label, value) pairs for the header block."""
    g = lambda k, d="—": (meta.get(k) or d)
    return [
        ("Project", g("project_name")),
        ("Engineer", g("engineer")),
        ("Client", g("client")),
        ("AOC (Area Operation Center)", g("aoc")),
        ("SCC (System Control Center)", g("scc")),
        ("Substation", g("station_name")),
        ("Voltage level", g("voltage_level")),
        ("Bay / Feeder", g("bay")),
        ("Date", g("date") or datetime.date.today().isoformat()),
    ]


def _is_status(type_id):
    n = TYPE_NAMES.get(type_id, "")
    return n.startswith("M_SP") or n.startswith("M_DP") or n.startswith("M_ST")


def _state_text(p):
    n = p.get("type_name", "")
    if n.startswith("M_DP"):
        return DPI_NAMES.get(p.get("value"), str(p.get("value")))
    if n.startswith("M_SP"):
        return "ON" if p.get("value") else "OFF"
    return str(p.get("display", p.get("value")))


def _group_by_type(points):
    groups = {}
    for p in points:
        tid = p.get("type_id") or p.get("expected_type")
        groups.setdefault(tid, []).append(p)
    # sort by type id, points by ioa
    out = []
    for tid in sorted(groups, key=lambda x: (x is None, x)):
        pts = sorted(groups[tid], key=lambda x: x["ioa"])
        out.append((tid, pts))
    return out


def _timestamp_name(ext):
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    return f"IEC101-report-{ts}.{ext}"


# ===========================================================================
#  DOCX
# ===========================================================================
def build_docx(data):
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT

    meta = data.get("meta", {})
    cfg = data.get("config", {})
    points = data.get("points", [])

    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10)

    def heading(text, size=14, color=ACCENT, space_before=10):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(space_before)
        p.paragraph_format.space_after = Pt(4)
        r = p.add_run(text); r.bold = True; r.font.size = Pt(size)
        r.font.color.rgb = RGBColor(*color)
        return p

    # ---- title ----
    t = doc.add_paragraph(); t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = t.add_run(TITLE); r.bold = True; r.font.size = Pt(18)
    r.font.color.rgb = RGBColor(*ACCENT)
    sub = doc.add_paragraph(); sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    rs = sub.add_run("Point-to-point verification · IEC 60870-5-101")
    rs.font.size = Pt(10); rs.font.color.rgb = RGBColor(0x60, 0x70, 0x80)

    # ---- header meta table ----
    heading("Project information")
    rows = _meta_rows(meta)
    table = doc.add_table(rows=0, cols=2); table.style = "Light Grid Accent 1"
    for label, value in rows:
        cells = table.add_row().cells
        cells[0].width = Inches(2.4)
        rp = cells[0].paragraphs[0].add_run(label); rp.bold = True
        cells[1].paragraphs[0].add_run(str(value))

    # ---- link settings ----
    heading("Communication settings")
    ltable = doc.add_table(rows=0, cols=4); ltable.style = "Light Grid Accent 1"
    link = [
        ("Mode", data.get("status", {}).get("mode", "—"),
         "Link address", cfg.get("link_address")),
        ("Baud / parity", f"{cfg.get('baudrate','—')} {cfg.get('parity','')}",
         "Common address", cfg.get("common_address")),
        ("COT length", cfg.get("cot_len"), "IOA length", cfg.get("ioa_len")),
        ("Transmission", "balanced" if cfg.get("balanced") else "unbalanced",
         "Common addr len", cfg.get("common_len")),
    ]
    for a, b, c, d in link:
        cells = ltable.add_row().cells
        cells[0].paragraphs[0].add_run(str(a)).bold = True
        cells[1].paragraphs[0].add_run(str(b))
        cells[2].paragraphs[0].add_run(str(c)).bold = True
        cells[3].paragraphs[0].add_run(str(d))

    # ---- summary ----
    n_total = len(points)
    n_recv = sum(1 for p in points if p.get("received"))
    n_status = sum(1 for p in points if _is_status(p.get("type_id") or p.get("expected_type")))
    n_invalid = sum(1 for p in points if p.get("quality"))
    heading("Summary")
    s = doc.add_paragraph()
    s.add_run(f"Total points: {n_total}    Received: {n_recv}    "
              f"Status points: {n_status}    Invalid quality: {n_invalid}")

    # ---- addresses by type ----
    heading("Address list by type")
    for tid, pts in _group_by_type(points):
        name = TYPE_NAMES.get(tid, "undefined")
        desc = TYPE_DESC.get(tid, "")
        sub = doc.add_paragraph()
        rr = sub.add_run(f"{name}  (type {tid})" + (f" — {desc}" if desc else "")
                         + f"   [{len(pts)}]")
        rr.bold = True; rr.font.color.rgb = RGBColor(*SLATE)
        tb = doc.add_table(rows=1, cols=6); tb.style = "Light List Accent 1"
        hdr = tb.rows[0].cells
        for i, h in enumerate(["IOA", "Name", "Value", "Quality", "Received", "Cause"]):
            hr = hdr[i].paragraphs[0].add_run(h); hr.bold = True
        for p in pts:
            c = tb.add_row().cells
            c[0].paragraphs[0].add_run(str(p["ioa"]))
            c[1].paragraphs[0].add_run(p.get("name", "") or "—")
            c[2].paragraphs[0].add_run(str(p.get("display", "—")))
            qr = c[3].paragraphs[0].add_run(p.get("quality_text", ""))
            qr.font.color.rgb = RGBColor(*(RED if p.get("quality") else GREEN))
            c[4].paragraphs[0].add_run("yes" if p.get("received") else "no")
            c[5].paragraphs[0].add_run(p.get("cot_name", "") or "")

    # ---- switchgear status ----
    heading("Switchgear status & validity")
    status_pts = [p for p in points if _is_status(p.get("type_id") or p.get("expected_type"))]
    if status_pts:
        tb = doc.add_table(rows=1, cols=5); tb.style = "Light List Accent 1"
        for i, h in enumerate(["IOA", "Name", "Type", "State", "Valid"]):
            hr = tb.rows[0].cells[i].paragraphs[0].add_run(h); hr.bold = True
        for p in sorted(status_pts, key=lambda x: x["ioa"]):
            c = tb.add_row().cells
            c[0].paragraphs[0].add_run(str(p["ioa"]))
            c[1].paragraphs[0].add_run(p.get("name", "") or "—")
            c[2].paragraphs[0].add_run(p.get("type_name", "") or
                                       p.get("expected_type_name", ""))
            c[3].paragraphs[0].add_run(_state_text(p))
            valid = not p.get("quality") and p.get("received")
            vr = c[4].paragraphs[0].add_run("VALID" if valid else
                                            ("INVALID" if p.get("received") else "no data"))
            vr.font.color.rgb = RGBColor(*(GREEN if valid else RED)); vr.bold = True
    else:
        doc.add_paragraph("No status points defined or received.")

    # ---- signature ----
    heading("Sign-off", space_before=18)
    sig = doc.add_table(rows=1, cols=2)
    sig.rows[0].cells[0].paragraphs[0].add_run(
        f"\n\nEngineer: {meta.get('engineer','____________________')}\n\nSignature: ____________________")
    sig.rows[0].cells[1].paragraphs[0].add_run(
        "\n\nClient representative: ____________________\n\nSignature: ____________________")

    foot = doc.add_paragraph()
    fr = foot.add_run(f"Generated {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}"
                      " · IEC 60870-5-101 Tester")
    fr.font.size = Pt(8); fr.font.color.rgb = RGBColor(0x90, 0xa0, 0xb0)

    fname = _timestamp_name("docx")
    path = os.path.join(REPORT_DIR, fname)
    doc.save(path)
    return path, fname


# ===========================================================================
#  PDF
# ===========================================================================
def build_pdf(data):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                    TableStyle)
    from reportlab.lib.enums import TA_CENTER

    meta = data.get("meta", {})
    cfg = data.get("config", {})
    points = data.get("points", [])

    accent = colors.Color(*[c/255 for c in ACCENT])
    slate = colors.Color(*[c/255 for c in SLATE])
    green = colors.Color(*[c/255 for c in GREEN])
    red = colors.Color(*[c/255 for c in RED])

    styles = getSampleStyleSheet()
    h_title = ParagraphStyle("t", parent=styles["Title"], textColor=accent, fontSize=18)
    h_sub = ParagraphStyle("s", parent=styles["Normal"], alignment=TA_CENTER,
                           textColor=colors.HexColor("#607080"))
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], textColor=accent, fontSize=12,
                        spaceBefore=12, spaceAfter=4)
    h3 = ParagraphStyle("h3", parent=styles["Heading3"], textColor=slate, fontSize=10)
    body = styles["Normal"]; body.fontSize = 9

    fname = _timestamp_name("pdf")
    path = os.path.join(REPORT_DIR, fname)
    doc = SimpleDocTemplate(path, pagesize=A4, topMargin=16*mm, bottomMargin=14*mm,
                            leftMargin=15*mm, rightMargin=15*mm, title=TITLE)
    E = []
    E.append(Paragraph(TITLE, h_title))
    E.append(Paragraph("Point-to-point verification · IEC 60870-5-101", h_sub))
    E.append(Spacer(1, 8))

    def grid_style(header=True):
        cmds = [
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#c9d4dd")),
            ("FONTSIZE", (0, 0), (-1, -1), 8.5),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("ROWBACKGROUNDS", (0, 1 if header else 0), (-1, -1),
             [colors.white, colors.HexColor("#f2f6f9")]),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]
        if header:
            cmds += [("BACKGROUND", (0, 0), (-1, 0), accent),
                     ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                     ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold")]
        return TableStyle(cmds)

    # ---- project info ----
    E.append(Paragraph("Project information", h2))
    info = [[Paragraph(f"<b>{k}</b>", body), Paragraph(str(v), body)]
            for k, v in _meta_rows(meta)]
    t = Table(info, colWidths=[62*mm, 113*mm]); t.setStyle(grid_style(header=False))
    E.append(t)

    # ---- link settings ----
    E.append(Paragraph("Communication settings", h2))
    link = [
        ["Mode", data.get("status", {}).get("mode", "—"),
         "Link address", str(cfg.get("link_address"))],
        ["Baud / parity", f"{cfg.get('baudrate','—')} {cfg.get('parity','')}",
         "Common address", str(cfg.get("common_address"))],
        ["COT length", str(cfg.get("cot_len")), "IOA length", str(cfg.get("ioa_len"))],
        ["Transmission", "balanced" if cfg.get("balanced") else "unbalanced",
         "Common addr len", str(cfg.get("common_len"))],
    ]
    t = Table(link, colWidths=[40*mm, 47*mm, 40*mm, 48*mm]); t.setStyle(grid_style(header=False))
    E.append(t)

    # ---- summary ----
    n_total = len(points); n_recv = sum(1 for p in points if p.get("received"))
    n_status = sum(1 for p in points if _is_status(p.get("type_id") or p.get("expected_type")))
    n_invalid = sum(1 for p in points if p.get("quality"))
    E.append(Paragraph("Summary", h2))
    E.append(Paragraph(
        f"Total points: <b>{n_total}</b> &nbsp;&nbsp; Received: <b>{n_recv}</b> "
        f"&nbsp;&nbsp; Status points: <b>{n_status}</b> &nbsp;&nbsp; "
        f"Invalid quality: <b>{n_invalid}</b>", body))

    # ---- addresses by type ----
    E.append(Paragraph("Address list by type", h2))
    for tid, pts in _group_by_type(points):
        name = TYPE_NAMES.get(tid, "undefined"); desc = TYPE_DESC.get(tid, "")
        E.append(Paragraph(f"{name} (type {tid})" + (f" — {desc}" if desc else "")
                           + f" &nbsp; [{len(pts)}]", h3))
        rows = [["IOA", "Name", "Value", "Quality", "Rx", "Cause"]]
        for p in pts:
            rows.append([str(p["ioa"]), p.get("name", "") or "—",
                         str(p.get("display", "—")), p.get("quality_text", ""),
                         "yes" if p.get("received") else "no", p.get("cot_name", "")])
        t = Table(rows, colWidths=[16*mm, 62*mm, 34*mm, 24*mm, 12*mm, 27*mm],
                  repeatRows=1)
        st = grid_style()
        for i, p in enumerate(pts, start=1):
            st.add("TEXTCOLOR", (3, i), (3, i), red if p.get("quality") else green)
        t.setStyle(st); E.append(t); E.append(Spacer(1, 4))

    # ---- switchgear ----
    E.append(Paragraph("Switchgear status &amp; validity", h2))
    status_pts = [p for p in points if _is_status(p.get("type_id") or p.get("expected_type"))]
    if status_pts:
        rows = [["IOA", "Name", "Type", "State", "Valid"]]
        colidx = []
        for p in sorted(status_pts, key=lambda x: x["ioa"]):
            valid = (not p.get("quality")) and p.get("received")
            rows.append([str(p["ioa"]), p.get("name", "") or "—",
                         p.get("type_name", "") or p.get("expected_type_name", ""),
                         _state_text(p),
                         "VALID" if valid else ("INVALID" if p.get("received") else "no data")])
            colidx.append(valid)
        t = Table(rows, colWidths=[16*mm, 70*mm, 34*mm, 30*mm, 25*mm], repeatRows=1)
        st = grid_style()
        for i, valid in enumerate(colidx, start=1):
            st.add("TEXTCOLOR", (4, i), (4, i), green if valid else red)
            st.add("FONTNAME", (4, i), (4, i), "Helvetica-Bold")
        t.setStyle(st); E.append(t)
    else:
        E.append(Paragraph("No status points defined or received.", body))

    # ---- sign-off ----
    E.append(Spacer(1, 16))
    sign = [[Paragraph(f"Engineer: {meta.get('engineer','') or '________________'}<br/><br/>"
                       "Signature: ________________", body),
             Paragraph("Client representative: ________________<br/><br/>"
                       "Signature: ________________", body)]]
    t = Table(sign, colWidths=[87*mm, 88*mm])
    t.setStyle(TableStyle([("TOPPADDING", (0, 0), (-1, -1), 10)]))
    E.append(t)
    E.append(Spacer(1, 8))
    E.append(Paragraph(
        f"<font size=7 color='#90a0b0'>Generated "
        f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} · "
        f"IEC 60870-5-101 Tester</font>", body))

    doc.build(E)
    return path, fname
