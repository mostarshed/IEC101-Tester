@echo off
REM ======================================================================
REM  IEC 60870-5-101 Tester  -  one-click launcher for Windows
REM  Creates a local Python environment on first run, installs the
REM  dependencies, starts the server and opens your browser.
REM ======================================================================
setlocal enabledelayedexpansion
title IEC 60870-5-101 Tester
cd /d "%~dp0"

echo.
echo   ====================================================
echo    IEC 60870-5-101 Protocol Tester
echo    Substation gateway commissioning tool
echo   ====================================================
echo.

REM --- 1) locate a Python interpreter --------------------------------------
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY ( where python >nul 2>&1 && set "PY=python" )
if not defined PY (
  echo   [ERROR] Python 3 was not found on this PC.
  echo.
  echo   Please install Python 3.9 or newer from:
  echo       https://www.python.org/downloads/
  echo   During installation, tick "Add Python to PATH".
  echo.
  pause
  exit /b 1
)
echo   [1/4] Using Python: %PY%
%PY% --version

REM --- 2) create the virtual environment (first run only) ------------------
if not exist ".venv\Scripts\python.exe" (
  echo   [2/4] Creating local environment ^(first run, please wait^)...
  %PY% -m venv .venv
  if errorlevel 1 (
     echo   [ERROR] Could not create the virtual environment.
     pause & exit /b 1
  )
) else (
  echo   [2/4] Local environment found.
)

set "VPY=.venv\Scripts\python.exe"

REM --- 3) install / update dependencies ------------------------------------
if not exist ".venv\.installed" (
  echo   [3/4] Installing dependencies ^(first run only^)...
  "%VPY%" -m pip install --upgrade pip >nul 2>&1
  "%VPY%" -m pip install -r requirements.txt
  if errorlevel 1 (
     echo   [ERROR] Dependency installation failed. Check your internet connection.
     pause & exit /b 1
  )
  echo ok> ".venv\.installed"
) else (
  echo   [3/4] Dependencies already installed.
)

REM --- 4) launch -----------------------------------------------------------
set "IEC101_HOST=127.0.0.1"
set "IEC101_PORT=8101"
echo   [4/4] Starting server...
echo.
echo   The app picks a free port automatically and opens your browser.
echo   Keep this window open while you use the tool. Press Ctrl+C to stop.
echo.

cd app
"..\.venv\Scripts\python.exe" server.py

echo.
echo   Server stopped.
pause
endlocal
