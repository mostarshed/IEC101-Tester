#!/usr/bin/env bash
# ======================================================================
#  IEC 60870-5-101 Tester  -  launcher for Linux / macOS
# ======================================================================
set -e
cd "$(dirname "$0")"

echo
echo "  ===================================================="
echo "   IEC 60870-5-101 Protocol Tester"
echo "   Substation gateway commissioning tool"
echo "  ===================================================="
echo

PY=python3
command -v $PY >/dev/null 2>&1 || { echo "[ERROR] python3 not found. Install Python 3.9+"; exit 1; }
echo "  [1/4] Using $($PY --version)"

if [ ! -x ".venv/bin/python" ]; then
  echo "  [2/4] Creating local environment (first run)..."
  $PY -m venv .venv
else
  echo "  [2/4] Local environment found."
fi

VPY=".venv/bin/python"

if [ ! -f ".venv/.installed" ]; then
  echo "  [3/4] Installing dependencies (first run only)..."
  "$VPY" -m pip install --upgrade pip >/dev/null 2>&1 || true
  "$VPY" -m pip install -r requirements.txt
  echo ok > ".venv/.installed"
else
  echo "  [3/4] Dependencies already installed."
fi

export IEC101_HOST=127.0.0.1
export IEC101_PORT=8101
echo "  [4/4] Starting server (auto-selects a free port, opens browser)…"
echo "  Keep this terminal open. Press Ctrl+C to stop."
echo

cd app
exec "../.venv/bin/python" server.py
