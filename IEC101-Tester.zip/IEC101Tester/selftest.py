# -*- coding: utf-8 -*-
"""Standalone self-test of the IEC 101 stack over the virtual pair."""
import time, sys
sys.path.insert(0, "app")
from iec101 import (LinkMaster, SlaveSimulator, VirtualPair, commands)
from iec101.asdu import Sizes
from iec101.frame import Frame, FrameDecoder, checksum

# --- 1) framing round trip -------------------------------------------------
f = Frame.variable(0x73, 1, bytes([0x64, 0x01, 0x06, 0x01, 0x00, 0x00, 0x14]), addr_len=2)
enc = f.encode()
dec = FrameDecoder(addr_len=2).feed(enc)
assert dec and dec[0].asdu == f.asdu, "variable frame round trip failed"
print("[OK] FT1.2 variable frame round-trip, checksum =", hex(checksum(bytes([0x73,1,0]))))

# --- 2) master + simulator -------------------------------------------------
events = []
def sink(e): events.append(e.to_dict())

cfg = dict(link_address=1, link_addr_len=2, common_address=1,
           cot_len=2, common_len=2, ioa_len=3, poll_interval=0.3,
           response_timeout=0.5, balanced=False)
pair = VirtualPair(latency=0.001)
slave = SlaveSimulator(pair.slave, cfg, on_event=sink)
master = LinkMaster(pair.master, cfg, on_event=sink)
slave.start(); master.start()
time.sleep(1.5)

# general interrogation
master.send_asdu(commands.general_interrogation(1, master.sizes, group=20))
time.sleep(2.0)

# double command CLOSE to breaker 1001 (direct execute)
master.send_asdu(commands.double_command(1, master.sizes, 1001, state=2))
time.sleep(1.5)

master.stop(); slave.stop()

# --- 3) summarise ----------------------------------------------------------
rx_asdus = [e for e in events if e.get("kind") == "frame"
            and e.get("direction") == "rx" and e.get("asdu")]
types = {}
for e in events:
    a = e.get("asdu")
    if a:
        types[a["type_name"]] = types.get(a["type_name"], 0) + 1
print("[OK] master link_up stats:", master.stats)
print("[OK] ASDU types seen:", types)
mv = [o for e in events if e.get("asdu") and e["asdu"]["type_name"]=="M_ME_NC_1"
      for o in e["asdu"]["objects"]]
print("[OK] sample measured values:", [(o["ioa"], o["value"]) for o in mv[:4]])
breaker = [o for e in events if e.get("asdu")
           for o in e["asdu"]["objects"] if o["ioa"] == 1001]
print("[OK] breaker 1001 states observed:", [o["value"] for o in breaker])
assert master.stats["rx_frames"] > 5, "no frames received"
assert "M_ME_NC_1" in types, "no measured values"
assert "C_IC_NA_1" in types, "interrogation not mirrored"
print("\nALL CORE TESTS PASSED")
